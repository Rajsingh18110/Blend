
let LINK_TARGET = '_self';
let SETTINGS_CSS = '';
try {
  LINK_TARGET = localStorage.getItem('blend_newtab') === '1' ? '_blank' : '_self';
  SETTINGS_CSS = `
    ${localStorage.getItem('blend_favicons') === '0' ? '.result-favicon { display: none !important; }' : ''}
    ${localStorage.getItem('blend_compact') === '1' ? '.result-card { padding: 10px 14px !important; margin-bottom: 8px !important; } .result-title { font-size: 16px !important; margin-bottom: 3px !important; } .result-desc { font-size: 13px !important; line-height: 1.35 !important; }' : ''}
  `;
} catch (e) { console.log('Storage access blocked', e); }

const styleSheet = document.createElement("style");
styleSheet.innerText = SETTINGS_CSS;
document.head.appendChild(styleSheet);

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function escapeJs(value) {
  return String(value || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}

function getDomain(url) {
  try {
    const u = new URL(url.startsWith('http') ? url : `https://${url}`);
    return u.hostname.replace(/^www\./, '');
  } catch (e) {
    return String(url || '').replace(/^https?:\/\//, '').split('/')[0].replace(/^www\./, '');
  }
}

function guessDomainsFromQuery(q) {
  const base = String(q || '').toLowerCase().trim().replace(/\s+/g, '').replace(/[^a-z0-9.-]/g, '');
  if (!base || base.length < 3) return [];
  if (base.includes('.')) return [base];
  return [base + '.com', base + '.in', base + '.org', base + '.net', base + '.io'];
}

function urlMatchesDomain(url, domains) {
  const domain = getDomain(url).toLowerCase();
  return domains.some(d => domain === d || domain.endsWith(`.${d}`));
}

function dedupeResults(results) {
  const seen = new Set();
  return (results || []).filter(r => {
    const key = r.url || r.title || JSON.stringify(r);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function boostByUrl(q, results) {
  const domains = guessDomainsFromQuery(q);
  if (!domains.length) return results || [];
  const official = [];
  const rest = [];
  (results || []).forEach(r => (urlMatchesDomain(r.url || r.img_src || '', domains) ? official : rest).push(r));
  return [...official, ...rest];
}

function selectedSearchMode() {
  const select = document.getElementById('mode-select');
  const mode = select?.value || new URLSearchParams(window.location.search).get('mode') || 'fast';
  return mode === 'deep' ? 'deep' : 'fast';
}

function searchModeLabel(mode) {
  return mode === 'deep' ? 'Deep Search · Crawl4AI' : 'Fast Search';
}

function searchModeQueryPart() {
  return selectedSearchMode() === 'deep' ? '&mode=deep' : '';
}

function applySearchModeParam(params) {
  if (selectedSearchMode() === 'deep') params.set('mode', 'deep');
  else params.delete('mode');
  return params;
}

function deepResultBadge(result) {
  if (!result || result.deep_engine !== 'Crawl4AI') return '';
  const status = result.deep_verified ? 'verified' : 'attempted';
  const color = result.deep_verified ? 'var(--accent)' : 'var(--text3)';
  return `<span style="display:inline-flex;align-items:center;gap:4px;font-size:10px;font-weight:800;color:${color};border:1px solid color-mix(in srgb, ${color} 45%, var(--border));border-radius:999px;padding:2px 7px;text-transform:uppercase;letter-spacing:0.4px;">Crawl4AI ${status}</span>`;
}

function showDeepSearchPending(category, q) {
  const panel = document.getElementById('deep-search-panel');
  if (!panel) return;
  if (selectedSearchMode() !== 'deep') {
    panel.style.display = 'none';
    return;
  }
  panel.style.display = 'block';
  document.getElementById('deep-search-summary').textContent = `Preparing Crawl4AI enrichment for ${category || 'web'} results: "${q || ''}"`;
  document.getElementById('deep-search-counters').innerHTML = [
    ['Mode', 'Deep'],
    ['Engine', 'Crawl4AI'],
    ['Status', 'running']
  ].map(([label, value]) => `<span style="font-size:11px;color:var(--text2);border:1px solid var(--border);border-radius:999px;padding:5px 9px;"><strong style="color:var(--text);">${label}</strong> ${value}</span>`).join('');
  document.getElementById('deep-search-proof').textContent = 'Pipeline: BlendEngine discovery finds candidate URLs first, then Crawl4AI crawls and extracts content from the top safe URLs.';
}

function updateDeepSearchPanel(data, category) {
  const panel = document.getElementById('deep-search-panel');
  if (!panel) return;
  if (selectedSearchMode() !== 'deep') {
    panel.style.display = 'none';
    return;
  }

  const deep = data?.deep_search || {};
  const pipeline = data?.pipeline || {};
  const crawled = Array.isArray(deep.crawled_urls) ? deep.crawled_urls.filter(Boolean) : [];
  const sourceList = Array.isArray(pipeline.discovery_sources) ? pipeline.discovery_sources : (deep.initial_discovery || []);
  panel.style.display = 'block';
  document.getElementById('deep-search-summary').textContent =
    `${deep.engine || 'Crawl4AI'} ${deep.status || 'completed'} for ${category || deep.category || 'results'} · ${deep.successful || 0}/${deep.attempted || 0} URLs enriched`;

  const counters = [
    ['Attempted', deep.attempted ?? 0],
    ['Crawled', deep.successful ?? 0],
    ['Failed', deep.failed ?? 0],
    ['Route', pipeline.legacy_route_used || deep.legacy_route_used ? 'LegacyRoute' : 'BlendEngine'],
    ['Extractor', deep.engine || pipeline.deep_enrichment || 'Crawl4AI']
  ];
  document.getElementById('deep-search-counters').innerHTML = counters.map(([label, value]) =>
    `<span style="font-size:11px;color:var(--text2);border:1px solid var(--border);border-radius:999px;padding:5px 9px;"><strong style="color:var(--text);">${escapeHtml(label)}</strong> ${escapeHtml(value)}</span>`
  ).join('');

  const crawledHtml = crawled.length
    ? `<div style="margin-top:6px;">Crawled URLs: ${crawled.slice(0, 3).map(url => `<code style="color:var(--text2);">${escapeHtml(url)}</code>`).join(' · ')}</div>`
    : '<div style="margin-top:6px;">No URL content was extracted yet. Results still came from discovery providers.</div>';
  document.getElementById('deep-search-proof').innerHTML =
    `API proof: <code>mode=${escapeHtml(data?.mode || 'deep')}</code> · <code>deep_enrichment=${escapeHtml(pipeline.deep_enrichment || deep.engine || 'Crawl4AI')}</code> · <code>blend_route=${escapeHtml(pipeline.legacy_route_used || deep.legacy_route_used ? 'legacy' : 'native')}</code> · Discovery: ${escapeHtml(sourceList.join(', ') || 'unknown')}${crawledHtml}`;
}

function currentTabName() {
  return document.querySelector('.tab-btn.active')?.dataset?.tab || new URLSearchParams(window.location.search).get('tab') || 'web';
}

function resetTabState(tab) {
  if (tab === 'web') window.CURRENT_RESULTS = [];
  if (tab === 'images') window.allImages = [];
  if (tab === 'videos') delete document.getElementById('full-videos').dataset.loaded;
  if (tab === 'news') delete document.getElementById('news-list').dataset.loaded;
  if (tab === 'files') delete document.getElementById('files-list').dataset.loaded;
  if (tab === 'social') delete document.getElementById('social-list').dataset.loaded;
}

function resetSearchModeState() {
  window.CURRENT_RESULTS = [];
  window.allImages = [];
  ['full-videos', 'news-list', 'files-list', 'social-list'].forEach(id => {
    const el = document.getElementById(id);
    if (el) delete el.dataset.loaded;
  });
}

function renderActiveSearchTab(tab, q) {
  if (tab === 'web') renderWeb(q);
  if (tab === 'images') renderImages(q);
  if (tab === 'videos') renderVideos(q);
  if (tab === 'news') renderNews(q);
  if (tab === 'files') renderFiles(q);
  if (tab === 'social') renderSocial(q);
  if (tab === 'maps') renderMapPlaces(q);
  if (tab === 'music') renderMusic(q);
}

function deepTextPreview(markdown, maxLength = 520) {
  return String(markdown || '')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/!\[[^\]]*\]\([^\)]+\)/g, ' ')
    .replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1')
    .replace(/[#>*_\-\|]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, maxLength);
}

function resultCard(r, idx) {
  const domain = (r.parsed_url && r.parsed_url[1]) || getDomain(r.url || '');
  const favicon = `https://www.google.com/s2/favicons?sz=64&domain=${domain}`;
  const deepPreview = deepTextPreview(r.deep_content);
  const subPages = Array.isArray(r.sub_pages) ? r.sub_pages.filter(Boolean).slice(0, 2) : [];
  
  const officialDomains = [
    'wikipedia.org', 'github.com', 'stackoverflow.com', 'reddit.com', 'quora.com',
    'developer.mozilla.org', 'docs.microsoft.com', 'medium.com', 'youtube.com',
    'apple.com', 'microsoft.com', 'google.com', 'amazon.com', 'readxhub.in',
    'w3schools.com', 'geeksforgeeks.org', 'ncbi.nlm.nih.gov', 'arxiv.org'
  ];
  let verifiedBadge = '';
  if (officialDomains.some(d => domain === d || domain.endsWith('.' + d))) {
     verifiedBadge = `<span style="display:inline-flex;align-items:center;margin-left:6px;color:#00d084;font-size:12px;" title="Trusted Source"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg></span>`;
  }
  let tldLabel = '';
  if (domain.endsWith('.gov') || domain.endsWith('.edu') || domain.endsWith('.ac.uk')) {
     tldLabel = `<span style="background:var(--accent);color:#000;padding:1px 6px;border-radius:10px;font-size:10px;font-weight:800;margin-left:8px;letter-spacing:0.5px;">OFFICIAL</span>`;
  }

  return `
    <div class="result-card" style="animation: fadeIn 0.3s ease ${idx * 0.05}s;">
      <div class="result-source" style="display:flex;align-items:center;">
        <div class="result-favicon"><img src="${favicon}" style="width:16px;height:16px;border-radius:4px;" onerror="this.style.display='none'" /></div>
        <span class="result-url" style="display:flex;align-items:center;color:var(--text);font-weight:500;">${escapeHtml(domain || r.url)}${verifiedBadge}${tldLabel}</span>
      </div>
      <a href="${escapeHtml(r.url || '#')}" target="${LINK_TARGET}" class="result-title">${escapeHtml(r.title || 'Untitled result')}</a>
      <p class="result-desc">${escapeHtml(r.content || r.snippet || '')}</p>
      ${(deepPreview || subPages.length) ? `
        <div style="margin-top:12px;padding:12px 14px;background:color-mix(in srgb, var(--accent) 8%, transparent);border:1px solid color-mix(in srgb, var(--accent) 28%, var(--border));border-radius:10px;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;font-size:11px;font-weight:800;color:var(--accent);text-transform:uppercase;letter-spacing:0.5px;">
            <span style="width:7px;height:7px;border-radius:50%;background:var(--accent);box-shadow:0 0 10px var(--accent);"></span>
            Crawl4AI Deep Search
          </div>
          ${deepPreview ? `<p style="margin:0;color:var(--text2);font-size:13px;line-height:1.55;">${escapeHtml(deepPreview)}${String(r.deep_content || '').length > deepPreview.length ? '...' : ''}</p>` : ''}
          ${subPages.length ? `
            <div style="display:flex;flex-direction:column;gap:6px;margin-top:10px;">
              ${subPages.map(page => `
                <a href="${escapeHtml(page.url || '#')}" target="${LINK_TARGET}" style="font-size:12px;color:var(--link);text-decoration:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(page.url || 'Crawled sub-page')}</a>
              `).join('')}
            </div>` : ''}
        </div>` : ''}
      <div class="result-actions" style="margin-top:10px;display:flex;gap:16px;">
        <a class="result-action-link" href="${escapeHtml(r.url || '#')}" target="${LINK_TARGET}" style="display:flex;align-items:center;gap:4px;"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/></svg> Open</a>
        <a class="result-action-link" href="results.html?q=${encodeURIComponent('site:' + domain)}&tab=web">More from ${domain}</a>
        <a class="result-action-link" href="#" onclick="navigator.clipboard.writeText('${escapeJs(r.url || '')}');return false;">Copy Link</a>
      </div>
    </div>`;
}

function markanmTrustedResults(q) {
  const base = String(q || '').toLowerCase().trim().replace(/\s+/g, '');
  if (base !== 'markanm') return [];
  return [
    {
      url: 'https://markanm.com',
      title: 'MarkanM - Collaborative Tech Network',
      content: 'MarkanM is a non-profit collaborative tech network building privacy-first products, AI tools, and community-driven open-source projects.',
    },
    {
      url: 'https://markanm.com/about',
      title: 'About MarkanM',
      content: 'Learn about MarkanM, its mission, products, and community work.',
    },
    {
      url: 'https://markanm.com/contact',
      title: 'Contact MarkanM',
      content: 'Contact MarkanM and connect with the team.',
    },
    {
      url: 'https://markanm.in',
      title: 'MarkanM - A Collaborative Tech Community',
      content: 'MarkanM India community site for technology, learning, collaboration, and open-source work.',
    },
    {
      url: 'https://markanm.in/projects',
      title: 'Our Projects - MarkanM India',
      content: 'Explore the open-source projects built by the MarkanM India community.',
    },
    {
      url: 'https://markanm.in/join',
      title: 'Join MarkanM Community',
      content: 'Become a part of the fastest growing collaborative tech network in India.',
    }
  ];
}

function siteLinksResultBlock(domain, results) {
  const links = dedupeResults(results).filter(r => !isSocialUrl(r.url || ''));
  const primary = links[0] || { url: `https://${domain}`, title: domain, content: 'Matched pages from this domain.' };
  const favicon = `https://www.google.com/s2/favicons?sz=64&domain=${domain}`;
  
  // Strip trailing slash for accurate comparison
  const primaryUrlNorm = primary.url.replace(/\/$/, '').toLowerCase();
  
  const sitelinksAll = links.filter(r => {
      const urlNorm = (r.url || '').replace(/\/$/, '').toLowerCase();
      // Also filter out any sitelink that is literally just the domain name homepage
      const domainNorm = `https://${domain}`.toLowerCase();
      const domainWwwNorm = `https://www.${domain}`.toLowerCase();
      return urlNorm !== primaryUrlNorm && urlNorm !== domainNorm && urlNorm !== domainWwwNorm;
  });
  
  const visibleLinks = sitelinksAll.slice(0, 4);
  const hiddenLinks = sitelinksAll.slice(4);
    
  const officialDomains = [
    'wikipedia.org', 'github.com', 'stackoverflow.com', 'reddit.com', 'quora.com',
    'developer.mozilla.org', 'docs.microsoft.com', 'medium.com', 'youtube.com', 'readxhub.in'
  ];
  let verifiedBadge = '';
  if (officialDomains.some(d => domain === d || domain.endsWith('.' + d))) {
     verifiedBadge = `<span style="display:inline-flex;align-items:center;margin-left:6px;color:#00d084;font-size:12px;" title="Trusted Source"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg></span>`;
  }
  let tldLabel = '';
  if (domain.endsWith('.gov') || domain.endsWith('.edu') || domain.endsWith('.ac.uk')) {
     tldLabel = `<span style="background:var(--accent);color:#000;padding:1px 6px;border-radius:10px;font-size:10px;font-weight:800;margin-left:8px;letter-spacing:0.5px;">OFFICIAL</span>`;
  }

  const renderItem = (r) => `
    <a href="${escapeHtml(r.url)}" target="${LINK_TARGET}" style="display:block; text-decoration:none; padding: 6px 0 10px 0; transition: background 0.2s; position:relative; group">
       <div style="display:flex; align-items:center; justify-content:space-between;">
         <h3 style="font-size:16px; color:var(--link); margin:0; font-weight:500; text-decoration:none;" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">${escapeHtml(r.title || getDomain(r.url))}</h3>
       </div>
       <p style="font-size:13px; color:var(--text2); line-height:1.5; margin:4px 0 0 0; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;">${escapeHtml(r.content || '')}</p>
    </a>
  `;

  const uniqueId = 'sitelinks-' + Math.random().toString(36).substr(2, 9);

  return `
    <div class="result-card sitelinks-result-card" style="padding-bottom: 8px; border: none; background: transparent; padding-left: 0; padding-right: 0; box-shadow: none;">
      <div class="result-source" style="display:flex;align-items:center;gap:12px;">
        <div class="result-favicon" style="width:28px;height:28px;background:var(--bg3);border-radius:50%;display:flex;align-items:center;justify-content:center;">
            <img src="${favicon}" style="width:16px;height:16px;border-radius:50%;" onerror="this.style.display='none'" />
        </div>
        <div style="display:flex; flex-direction:column; line-height:1.2;">
          <span class="result-url" style="color:var(--text);font-weight:500;font-size:14px;display:flex;align-items:center;">${escapeHtml(domain)}${verifiedBadge}${tldLabel}</span>
          <span style="color:var(--text2);font-size:12px; margin-top:2px;">https://${escapeHtml(domain)}</span>
        </div>
      </div>
      <a href="${escapeHtml(primary.url)}" target="${LINK_TARGET}" class="result-title" style="font-size:22px; margin-top:14px; display:inline-block;">${escapeHtml(primary.title || domain)}</a>
      <p class="result-desc" style="margin-top:8px; font-size:14px; line-height:1.5; color:var(--text2);">${escapeHtml(primary.content || primary.snippet || 'Matched domain result from Blend Search.')}</p>
      
      ${visibleLinks.length ? `
        <div class="sitelinks-list" style="display:flex; flex-direction:column; margin-top: 20px; margin-left: 20px;">
          ${visibleLinks.map(r => renderItem(r)).join('')}
          
          ${hiddenLinks.length ? `
          <div id="${uniqueId}" style="display:none;">
            ${hiddenLinks.map(r => renderItem(r)).join('')}
          </div>
          <button onclick="
            const el = document.getElementById('${uniqueId}');
            const btn = this;
            if(el.style.display === 'none') {
               el.style.display = 'block';
               btn.innerHTML = 'Show less <svg width=\\'14\\' height=\\'14\\' viewBox=\\'0 0 24 24\\' fill=\\'none\\' stroke=\\'currentColor\\' stroke-width=\\'2\\' stroke-linecap=\\'round\\' stroke-linejoin=\\'round\\' style=\\'margin-left:4px;\\'><polyline points=\\'18 15 12 9 6 15\\'></polyline></svg>';
            } else {
               el.style.display = 'none';
               btn.innerHTML = 'More results from ${domain} <svg width=\\'14\\' height=\\'14\\' viewBox=\\'0 0 24 24\\' fill=\\'none\\' stroke=\\'currentColor\\' stroke-width=\\'2\\' stroke-linecap=\\'round\\' stroke-linejoin=\\'round\\' style=\\'margin-left:4px;\\'><polyline points=\\'6 9 12 15 18 9\\'></polyline></svg>';
            }
          " style="display:inline-flex; align-items:center; padding: 10px 0; color:var(--link); font-size:14px; font-weight:500; background:none; border:none; cursor:pointer; width:100%; text-align:left;" onmouseover="this.style.textDecoration='underline'" onmouseout="this.style.textDecoration='none'">
            More results from ${domain} <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left:4px;"><polyline points="6 9 12 15 18 9"></polyline></svg>
          </button>
          ` : ''}
        </div>` : ''}
    </div>`;
}

function isSocialUrl(url) {
  return /(^|\/\/)(www\.)?(instagram\.com|twitter\.com|x\.com|linkedin\.com|github\.com|facebook\.com)\//i.test(url || '');
}

function emptyState(icon, title, desc, retryCallback = null) {
  const retryHtml = retryCallback
    ? `<button onclick="${retryCallback}" class="empty-retry">Try Again</button>`
    : '';
  return `
    <div class="empty-state">
      <div class="empty-state-icon">${icon}</div>
      <div class="empty-state-title">${escapeHtml(title)}</div>
      <div class="empty-state-desc">${escapeHtml(desc)}</div>
      ${retryHtml}
    </div>`;
}

/* ── RENDER FUNCTIONS ── */
async function renderWeb(q) {
  const el = document.getElementById('web-results');
  const statsEl = document.getElementById('web-stats');
  const startedAt = performance.now();
  const mode = selectedSearchMode();
  const modeParam = searchModeQueryPart();
  showDeepSearchPending('web', q);
  
  // High quality skeleton loaders
  el.innerHTML = Array(5).fill(0).map(() => `
    <div class="result-card" style="opacity:0.6; pointer-events:none;">
      <div style="width:120px; height:12px; background:var(--bg3); border-radius:4px; margin-bottom:12px; animation: shimmer 1.5s infinite linear;"></div>
      <div style="width:80%; height:20px; background:var(--bg3); border-radius:4px; margin-bottom:12px; animation: shimmer 1.5s infinite linear;"></div>
      <div style="width:100%; height:14px; background:var(--bg3); border-radius:4px; margin-bottom:8px; animation: shimmer 1.5s infinite linear;"></div>
      <div style="width:60%; height:14px; background:var(--bg3); border-radius:4px; animation: shimmer 1.5s infinite linear;"></div>
    </div>
  `).join('');
  if (statsEl) statsEl.textContent = mode === 'deep'
    ? `Crawl4AI is deep-searching "${q}"...`
    : `Searching live results for "${q}"...`;
  
  const pageno = new URLSearchParams(window.location.search).get('pageno') || '1';
  try {
    const domains = guessDomainsFromQuery(q);
    const officialDomains = domains.slice(0, 3);
    const siteQuery = officialDomains.length ? officialDomains.map(d => `site:${d}`).join(' OR ') : '';
    const [mainResult, siteResult] = await Promise.allSettled([
      fetch(API(`/api/search?q=${encodeURIComponent(q)}&pageno=${pageno}&format=json${modeParam}${window.LANG_PARAM || ''}`)),
      siteQuery ? fetch(API(`/api/search?q=${encodeURIComponent(siteQuery)}&pageno=${pageno}&format=json${window.LANG_PARAM || ''}`)) : Promise.resolve(null)
    ]);

    if (mainResult.status !== 'fulfilled' || !mainResult.value.ok) throw new Error('API Error');
    const data = await mainResult.value.json();
    updateDeepSearchPanel(data, 'web');
    let siteResults = [];
    if (siteResult.status === 'fulfilled' && siteResult.value && siteResult.value.ok) {
      const siteData = await siteResult.value.json();
      siteResults = siteData.results || [];
    }

    const mainResults = data.results || [];
    const trustedResults = markanmTrustedResults(q);
    
    // Find the TOP domain from our guessed domains that actually has results
    let cardDomain = '';
    const allFetched = [...trustedResults, ...siteResults, ...mainResults];
    for (let d of domains) {
       if (allFetched.some(r => urlMatchesDomain(r.url || '', [d]))) {
          cardDomain = d;
          break; // Stop at .com if it exists, otherwise fall back to .in
       }
    }
    
    // If we didn't find any of our guessed domains, just use the top result's domain
    let needsExtraSiteFetch = false;
    if (!cardDomain && mainResults.length > 0 && !isSocialUrl(mainResults[0].url)) {
        cardDomain = getDomain(mainResults[0].url);
        needsExtraSiteFetch = true; // We didn't fetch sitelinks for this domain in parallel!
    }

    // EXTRA FETCH for non-.com/.in domains (like .ai, .edu, etc.)
    if (needsExtraSiteFetch && cardDomain) {
      try {
        const extraSiteRes = await fetch(API(`/api/search?q=${encodeURIComponent('site:' + cardDomain)}&pageno=${pageno}&format=json${window.LANG_PARAM || ''}`));
        if (extraSiteRes.ok) {
           const extraSiteData = await extraSiteRes.json();
           siteResults = extraSiteData.results || [];
        }
      } catch (e) {}
    }

    const activeOfficialDomains = cardDomain ? [cardDomain] : [];

    const officialResults = dedupeResults([
      ...trustedResults.filter(r => !isSocialUrl(r.url || '') && urlMatchesDomain(r.url || '', activeOfficialDomains)),
      ...siteResults.filter(r => urlMatchesDomain(r.url || '', activeOfficialDomains)),
      ...mainResults.filter(r => urlMatchesDomain(r.url || '', activeOfficialDomains))
    ]);
    const shownUrls = new Set(officialResults.map(r => r.url));
    const siteGeneral = [
      ...trustedResults.filter(r => !isSocialUrl(r.url || '') && !shownUrls.has(r.url)),
      ...siteResults.filter(r => !shownUrls.has(r.url))
    ];
    siteGeneral.forEach(r => shownUrls.add(r.url));
    const boostedGeneral = dedupeResults([
      ...siteGeneral,
      ...boostByUrl(q, mainResults.filter(r => !shownUrls.has(r.url)))
    ]);
    window.CURRENT_RESULTS = dedupeResults([...officialResults, ...boostedGeneral]);
    window.SECTION_CACHE['web'] = window.CURRENT_RESULTS;
    
    if (window.CURRENT_RESULTS.length > 0) {
      const total = data.number_of_results && data.number_of_results > 0 ? data.number_of_results : window.CURRENT_RESULTS.length;
      const seconds = ((performance.now() - startedAt) / 1000).toFixed(2);
      if (statsEl) statsEl.textContent = `About ${Number(total).toLocaleString()} results (${seconds} seconds) · ${searchModeLabel(mode)}`;
      const firstOfficialDomain = officialResults.length ? getDomain(officialResults[0].url || '') : '';
      const priorityGeneral = boostedGeneral.filter(r => urlMatchesDomain(r.url || '', officialDomains));
      const restGeneral = boostedGeneral.filter(r => !urlMatchesDomain(r.url || '', officialDomains));
      el.innerHTML =
        (firstOfficialDomain ? siteLinksResultBlock(firstOfficialDomain, officialResults) : '') +
        priorityGeneral
          .map((r, idx) => resultCard(r, idx))
          .join('') +
        restGeneral
          .map((r, idx) => resultCard(r, idx + priorityGeneral.length))
          .join('');
      renderPagination();
      return;
    }
  } catch (err) { 
    console.log('Backend search failed', err);
  }
  
  window.CURRENT_RESULTS = [];
  if (statsEl) statsEl.textContent = `No live results found · Backend responded`;
  el.innerHTML = emptyState('🔍', `No results for "${q}"`, 'Try a different spelling, fewer words, or check the backend connection.', `renderWeb('${escapeJs(q)}')`);
}

function renderPagination() {
  const container = document.getElementById('dynamic-pagination');
  if (!container) return;
  const params = new URLSearchParams(window.location.search);
  const pageno = parseInt(params.get('pageno')) || 1;
  const q = params.get('q') || sessionStorage.getItem('blend_q') || '';
  if (!q) return;

  const prevPage = Math.max(1, pageno - 1);
  const nextPage = pageno + 1;

  let html = `
    <div style="display:flex; background:rgba(255,255,255,0.03); padding:8px; border-radius:30px; border:1px solid rgba(255,255,255,0.05); backdrop-filter:blur(12px); box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
      <button onclick="changePage(${prevPage})" style="width:40px; height:40px; border-radius:50%; background:transparent; border:none; color:var(--text2); display:flex; align-items:center; justify-content:center; cursor:pointer; transition:all 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'; this.style.color='var(--text)'" onmouseout="this.style.background='transparent'; this.style.color='var(--text2)'">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
      </button>
      <div style="display:flex; align-items:center; padding:0 12px; gap:8px;">
  `;

  for (let i = Math.max(1, pageno - 2); i <= pageno + 2; i++) {
    const isCurrent = i === pageno;
    const style = isCurrent 
      ? `width:36px; height:36px; border-radius:50%; background:var(--accent); border:none; color:#000; font-weight:700; cursor:pointer; box-shadow:0 0 15px rgba(224, 90, 43, 0.5);`
      : `width:36px; height:36px; border-radius:50%; background:transparent; border:none; color:var(--text2); font-weight:600; cursor:pointer; transition:all 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'; this.style.color='var(--text)'" onmouseout="this.style.background='transparent'; this.style.color='var(--text2)'`;
    html += `<button onclick="changePage(${i})" style="${style}">${i}</button>`;
  }

  html += `
      </div>
      <button onclick="changePage(${nextPage})" style="width:40px; height:40px; border-radius:50%; background:transparent; border:none; color:var(--text); display:flex; align-items:center; justify-content:center; cursor:pointer; transition:all 0.3s;" onmouseover="this.style.background='rgba(255,255,255,0.1)'; this.style.color='var(--accent)'" onmouseout="this.style.background='transparent'; this.style.color='var(--text)'">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>
      </button>
    </div>
  `;
  container.innerHTML = html;
  container.style.display = 'flex';
}

function changePage(num) {
  const params = new URLSearchParams(window.location.search);
  params.set('pageno', num);
  window.location.search = params.toString();
}

function videoCard(v, idx) {
  const ytId = extractYtId(v.url);
  const clickAction = `window.open('${v.url}', '_blank')`;
  return `<div class="video-card" onclick="${clickAction}" style="animation: slideIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) ${idx * 0.05}s both;">
    <div class="video-thumb" style="position:relative;">
      <img src="${v.thumbnail || v.thumb || v.img_src || 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=320&h=180&fit=crop'}" alt="${escapeHtml(v.title)}" loading="lazy" />
      <div style="position:absolute;top:8px;left:8px;z-index:3;">${deepResultBadge(v)}</div>
      <div class="play-overlay"><div class="play-btn-circle"><div class="play-icon"></div></div></div>
      <span class="duration-chip">${v.duration || v.length || 'Play'}</span>
    </div>
    <div class="video-info">
      <div class="video-title">${escapeHtml(v.title)}</div>
      <div class="video-meta">
        <span class="video-platform">${escapeHtml(v.platform || (v.parsed_url ? v.parsed_url[1] : 'Video'))}</span>
        <span>·</span><span>${escapeHtml(v.channel || v.author || v.source || 'Unknown')}</span>
        <span>·</span><span>${escapeHtml(v.views || v.publishedDate || '')}</span>
      </div>
    </div>
  </div>`;
}

function extractYtId(url) {
  if (!url) return null;
  // Already an ID (11 chars, no slash)
  if (/^[\w-]{11}$/.test(url)) return url;
  const m = String(url).match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+[&?]v=)|piped\.video\/watch\?v=|srv\.piped\.video\/watch\?v=)([\w-]{11})/);
  return m ? m[1] : null;
}

async function renderImages(q) {
  const el = document.getElementById('full-img-grid');
  const statsEl = document.getElementById('img-stats');
  const modePart = searchModeQueryPart();
  showDeepSearchPending('images', q);
  
  statsEl.innerHTML = selectedSearchMode() === 'deep' ? 'Crawl4AI deep-searching image sources...' : '🔄 Loading images...';
  el.innerHTML = '<div style="grid-column: 1/-1; padding:40px 20px;text-align:center;color:var(--text3);">🖼️ Finding images for "<strong>' + q + '</strong>"...</div>';
  
  window._imgPage = 1;
  window._imgQuery = q;
  window._seenImgUrls = new Set();

  try {
    const res = await fetch(API(`/api/search?q=${encodeURIComponent(q)}&categories=images&pageno=1&format=json${modePart}${window.LANG_PARAM || ''}`), { signal: AbortSignal.timeout(30000) });
    if (!res.ok) throw new Error('API Error');
    const data = await res.json();
    updateDeepSearchPanel(data, 'images');
    if (data.results && data.results.length > 0) {
      window.allImages = boostByUrl(q, data.results);
      window.SECTION_CACHE['images'] = window.allImages;
      window.allImages.forEach(img => window._seenImgUrls.add(img.img_src || img.url));
      statsEl.innerHTML = `About ${data.results.length.toLocaleString()} image results · ${searchModeLabel(selectedSearchMode())}`;
      displayImages(window.allImages);
      return;
    }
  } catch (e) { 
    console.log('Backend images failed', e);
  }
  
  window.allImages = [];
  statsEl.innerHTML = 'No image results';
  el.innerHTML = emptyState('🖼️', `No images for "${q}"`, 'Try a more visual search phrase or check image engines.', `renderImages('${escapeJs(q)}')`);
}

function imageCard(img, idx) {
  return `
    <div style="position:relative; margin-bottom:16px; animation: slideIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) ${idx * 0.05}s both; cursor:zoom-in; border-radius:12px; overflow:hidden; background:var(--surface); break-inside:avoid; transform:translateZ(0);" onclick="openLightbox('${(img.img_src || img.url || img.thumbnail_src || '').replace(/'/g, "\\'")}','${(img.title || '').replace(/'/g,"\\'")}')">
      <img src="${img.img_src || img.thumbnail_src || img.url}" alt="${img.title || 'Image'}" loading="lazy" style="width:100%; height:auto; display:block; transition:transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);" onerror="this.parentElement.style.display='none';" />
      <div style="position:absolute;top:8px;left:8px;z-index:2;">${deepResultBadge(img)}</div>
      <div style="position:absolute; inset:0; background:rgba(0,0,0,0); transition:background 0.3s;" onmouseover="this.parentElement.querySelector('img').style.transform='scale(1.08)'; this.style.background='rgba(0,0,0,0.2)'" onmouseout="this.parentElement.querySelector('img').style.transform='scale(1)'; this.style.background='rgba(0,0,0,0)'"></div>
      <div style="position:absolute; bottom:0; left:0; right:0; background:linear-gradient(to top, rgba(0,0,0,0.9) 0%, transparent 100%); padding:12px; padding-top:24px; color:white; font-size:12px; font-weight:500; opacity:0; transition:opacity 0.3s; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" onmouseover="this.style.opacity='1'; this.parentElement.querySelector('img').style.transform='scale(1.08)'" onmouseout="this.style.opacity='0'; this.parentElement.querySelector('img').style.transform='scale(1)'">${img.title || img.source || 'Image'}</div>
    </div>`;
}

function displayImages(images) {
  const el = document.getElementById('full-img-grid');
  if (!images || images.length === 0) {
    el.innerHTML = emptyState('🖼️', 'No images found', 'Try another filter or search phrase.');
    return;
  }
  
  // Premium Masonry Layout using CSS Columns
  el.style.display = 'block';
  el.style.columnCount = 'auto';
  el.style.columnWidth = '220px';
  el.style.columnGap = '16px';

  el.innerHTML = images.map((img, idx) => imageCard(img, idx)).join('');
}

function filterImages(type) {
  document.querySelectorAll('.img-filter-btn').forEach(b => {
    const isActive = b.textContent.toLowerCase().includes(type) || (type === 'all' && b.textContent.toLowerCase().includes('all'));
    b.style.background = isActive ? 'var(--accent)' : 'var(--surface)';
    b.style.color = isActive ? '#000' : 'var(--text2)';
    b.style.borderColor = isActive ? 'transparent' : 'var(--border2)';
  });
  const filtered = type === 'all' ? window.allImages : window.allImages.filter(img => (img.type || '').includes(type));
  displayImages(filtered);
}

async function loadMoreImages() {
  const q = window._imgQuery;
  if (!q) return;
  const btn = document.querySelector('[onclick="loadMoreImages()"]');
  if (btn) { btn.textContent = '⏳ Loading...'; btn.disabled = true; }
  window._imgPage = (window._imgPage || 1) + 1;
  try {
    const res = await fetch(API(`/api/search?q=${encodeURIComponent(q)}&categories=images&pageno=${window._imgPage}&format=json${searchModeQueryPart()}${window.LANG_PARAM || ''}`), { signal: AbortSignal.timeout(30000) });
    if (!res.ok) throw new Error('API Error');
    const data = await res.json();
    updateDeepSearchPanel(data, 'images');
    if (data.results && data.results.length > 0) {
      // Deduplicate against already shown images
      const seen = window._seenImgUrls || new Set();
      const newImgs = data.results.filter(img => {
        const key = img.img_src || img.url;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
      window._seenImgUrls = seen;
      if (newImgs.length > 0) {
        window.allImages = [...(window.allImages || []), ...newImgs];
        appendImages(newImgs);
        const statsEl = document.getElementById('img-stats');
        if (statsEl) statsEl.innerHTML = `About ${window.allImages.length.toLocaleString()} image results · Page ${window._imgPage}`;
      }
    }
  } catch (e) { console.log('Load more images failed', e); }
  if (btn) { btn.innerHTML = 'See more results <svg style="width:14px;height:14px;vertical-align:middle;margin-left:4px;" fill="currentColor" viewBox="0 0 24 24"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/></svg>'; btn.disabled = false; }
}

function appendImages(images) {
  const el = document.getElementById('full-img-grid');
  if (!el || !images || images.length === 0) return;
  const startIdx = (window.allImages || []).length - images.length;
  const fragment = document.createDocumentFragment();
  images.forEach((img, i) => {
    const wrapper = document.createElement('div');
    wrapper.innerHTML = imageCard(img, startIdx + i);
    fragment.appendChild(wrapper.firstElementChild);
  });
  el.appendChild(fragment);
}

async function renderVideos(q) {
  const el = document.getElementById('full-videos');
  const statsEl = document.getElementById('video-stats');
  const loadMoreWrap = document.getElementById('video-load-more-wrap');
  const modePart = searchModeQueryPart();
  showDeepSearchPending('videos', q);
  
  // Reset state
  window._videoQuery = q;
  window._videoPage = 1;
  window._seenVideoUrls = new Set();

  el.innerHTML = '<div style="grid-column:1/-1;padding:40px;text-align:center;color:var(--text3);"><div class="loading-spinner"></div><div>' + (selectedSearchMode() === 'deep' ? 'Crawl4AI deep-searching video pages for ' : 'Loading videos for ') + '<strong>' + escapeHtml(q) + '</strong>...</div></div>';
  if (loadMoreWrap) loadMoreWrap.style.display = 'none';
  
  try {
    const res = await fetch(API(`/api/search?q=${encodeURIComponent(q)}&categories=videos&format=json${modePart}${window.LANG_PARAM || ''}`));
    if (!res.ok) throw new Error('API Error');
    const data = await res.json();
    updateDeepSearchPanel(data, 'videos');
    let results = data.results || [];
    
    // Deduplicate and track seen URLs
    const seen = window._seenVideoUrls;
    results = results.filter(v => { if (seen.has(v.url)) return false; seen.add(v.url); return true; });
    results = boostByUrl(q, results);
    window.SECTION_CACHE['videos'] = results;
    
    if (results.length > 0) {
      if (statsEl) statsEl.textContent = `About ${results.length} video results · ${searchModeLabel(selectedSearchMode())}`;
      el.innerHTML = results.map((v, idx) => videoCard(v, idx)).join('');
      if (loadMoreWrap) loadMoreWrap.style.display = 'block';
      return;
    }
  } catch (e) { 
    console.log('Backend videos failed', e);
  }
  if (statsEl) statsEl.textContent = 'No video results found';
  el.innerHTML = emptyState('🎬', `No videos for "${q}"`, 'Try another topic or check backend video engines.', `renderVideos('${escapeJs(q)}')`);
}

async function loadMoreVideos() {
  const q = window._videoQuery;
  if (!q) return;
  const btn = document.getElementById('video-load-more-btn');
  if (btn) { btn.textContent = '⏳ Loading...'; btn.disabled = true; }
  window._videoPage = (window._videoPage || 1) + 1;
  
  try {
    const res = await fetch(API(`/api/search?q=${encodeURIComponent(q)}&categories=videos&pageno=${window._videoPage}&format=json${searchModeQueryPart()}${window.LANG_PARAM || ''}`));
    if (!res.ok) throw new Error();
    const data = await res.json();
    updateDeepSearchPanel(data, 'videos');
    let results = data.results || [];
    
    // Filter already-seen videos
    const seen = window._seenVideoUrls || new Set();
    const newVideos = results.filter(v => { if (seen.has(v.url)) return false; seen.add(v.url); return true; });
    window._seenVideoUrls = seen;
    
    if (newVideos.length > 0) {
      const el = document.getElementById('full-videos');
      const startIdx = el.children.length;
      newVideos.forEach((v, i) => {
        const wrapper = document.createElement('div');
        wrapper.innerHTML = videoCard(v, startIdx + i);
        el.appendChild(wrapper.firstElementChild);
      });
      const statsEl = document.getElementById('video-stats');
      if (statsEl) statsEl.textContent = `About ${el.children.length} video results · Page ${window._videoPage}`;
    }
  } catch (e) { console.log('Load more videos failed', e); }
  
  if (btn) { btn.textContent = '🎬 Load more videos'; btn.disabled = false; }
}
async function renderNews(q) {
  const el = document.getElementById('news-list');
  const modePart = searchModeQueryPart();
  showDeepSearchPending('news', q);
  el.innerHTML = '<div style="grid-column: 1/-1; padding:40px;text-align:center;color:var(--text3);"><div class="loading-spinner"></div><div>' + (selectedSearchMode() === 'deep' ? 'Crawl4AI verifying news pages for ' : 'Fetching live updates for ') + '<strong>' + escapeHtml(q) + '</strong>...</div></div>';
  try {
    const res = await fetch(API(`/api/search?q=${encodeURIComponent(q)}&categories=news&format=json${modePart}${window.LANG_PARAM || ''}`));
    if (!res.ok) throw new Error('API Error');
    const data = await res.json();
    updateDeepSearchPanel(data, 'news');
    if (data.results && data.results.length > 0) {
      const results = boostByUrl(q, data.results);
      window.SECTION_CACHE['news'] = results;
      document.getElementById('news-stats').textContent = `Top ${results.length} stories for "${q}" · ${searchModeLabel(selectedSearchMode())}`;
      el.innerHTML = results.map((n, idx) => `
        <div class="news-card" style="animation: slideIn 0.4s cubic-bezier(0.16, 1, 0.3, 1) ${idx * 0.05}s both;">
          ${n.img_src || n.thumbnail ? `<div class="news-thumb"><img src="${n.img_src || n.thumbnail}" alt="" loading="lazy" /></div>` : ''}
          <div class="news-info">
            <div class="news-title"><a href="${n.url}" target="${LINK_TARGET}">${escapeHtml(n.title)}</a></div>
            <div style="margin:6px 0;">${deepResultBadge(n)}</div>
            <p class="news-desc">${escapeHtml(n.content || '')}</p>
            ${n.deep_content ? `<p class="news-desc" style="border-left:2px solid var(--accent);padding-left:10px;margin-top:8px;">${escapeHtml(deepTextPreview(n.deep_content, 220))}</p>` : ''}
            <div class="news-source">
              <span style="color:var(--accent);">${escapeHtml((n.parsed_url && n.parsed_url[1]) || n.source || 'News')}</span>
              <span>·</span>
              <span>${escapeHtml(n.publishedDate || 'Just now')}</span>
            </div>
          </div>
        </div>`).join('');
      return;
    }
  } catch (e) { 
    console.log('Backend news failed', e);
  }
  el.innerHTML = emptyState('📰', `No news for "${q}"`, 'Try a broader topic or remove filters.', `renderNews('${escapeJs(q)}')`);
}

async function renderMapPlaces(q) {
  const el = document.getElementById('map-places');
  el.innerHTML = `<div style="padding:60px;text-align:center;color:var(--text3);"><div class="loading-spinner" style="margin:0 auto 16px;"></div>Detecting your location for accurate results…</div>`;

  // ── STEP 1: Smart Location Detection ──
  let lat = null, lon = null, locLabel = 'India';
  let gpsMethod = 'none'; 
  let gpsDenied = false;

  const isNearbyExplicit = /near(by)?|close|around|local|adjacent/i.test(q);
  const categoriesList = ['restaurant', 'cafe', 'hotel', 'hospital', 'pharmacy', 'atm', 'shopping', 'petrol', 'transit', 'museum', 'food', 'pizza', 'bank', 'park'];
  const isCategorySearch = categoriesList.some(c => q.toLowerCase().includes(c));
  
  // If it's not a category and not explicitly nearby, we treat it as a specific place search
  const isExplicitLocationSearch = (!isCategorySearch && !isNearbyExplicit && q.trim().length > 2);

  let targetGeo = null;
  let geocodeFailed = false;

  // 1. If explicit location (e.g. "Delhi" or "Sumbhi Bazar"), try to geocode it directly!
  if (isExplicitLocationSearch || q.toLowerCase().includes(' in ') || q.toLowerCase().includes(' near ')) {
      let searchLoc = q;
      if (q.toLowerCase().includes(' in ')) searchLoc = q.split(/ in /i).pop();
      if (q.toLowerCase().includes(' near ')) searchLoc = q.split(/ near /i).pop();
      try {
          const res = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(searchLoc)}&format=json&limit=1`);
          const data = await res.json();
          if (data && data.length > 0) {
              targetGeo = { lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon), city: data[0].display_name.split(',')[0], method: 'searched' };
          } else {
              geocodeFailed = true; // Nominatim didn't find it (like "Sumbhi Bazar")
          }
      } catch(e) { geocodeFailed = true; }
  }

  // 2. Fetch User's actual GPS / IP ONLY if they didn't explicitly search for a specific location
  // OR if they searched for a category like "Restaurants"
  if (!targetGeo && !geocodeFailed) {
      if (window.BLEND_GPS && window.BLEND_GPS.method === 'gps') {
        targetGeo = window.BLEND_GPS;
      } else {
        targetGeo = await new Promise((resolve) => {
          if (!navigator.geolocation) return resolve(null);
          navigator.geolocation.getCurrentPosition(
            pos => resolve({ lat: pos.coords.latitude, lon: pos.coords.longitude, method: 'gps' }),
            (err) => { if(err.code === err.PERMISSION_DENIED) gpsDenied = true; resolve(null); },
            { timeout: 4000, maximumAge: 60000 }
          );
        });
        if (!targetGeo) {
          gpsMethod = 'ip';
          try {
            const ipRes = await fetch('https://get.geojs.io/v1/ip/geo.json');
            const ipData = await ipRes.json();
            if (ipData.latitude && ipData.longitude) {
              targetGeo = { lat: parseFloat(ipData.latitude), lon: parseFloat(ipData.longitude), city: ipData.city, method: 'ip' };
            }
          } catch(e) {}
        }
      }
      if (targetGeo && targetGeo.method === 'gps') window.BLEND_GPS = targetGeo;
  }

  if (targetGeo) {
    lat = targetGeo.lat; lon = targetGeo.lon; gpsMethod = targetGeo.method;
    try {
      const geo = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`, { headers: { "Accept-Language": "en" } });
      const geoData = await geo.json();
      const addr = geoData.address || {};
      locLabel = addr.suburb || addr.neighbourhood || addr.city_district || addr.city || addr.town || addr.county || targetGeo.city || 'Your Location';
    } catch(_) { locLabel = targetGeo.city || 'Your Location'; }
  } else {
    // If geocode failed for an explicit search, just use the query as the label
    locLabel = q;
  }

  // ── STEP 2: Build Map Src ──
  let finalQuery = q;
  if (!isNearbyExplicit && isCategorySearch && lat && lon && !q.toLowerCase().includes(locLabel.toLowerCase())) {
     finalQuery = `${q} near ${locLabel}`;
  }
  if (!isCategorySearch) {
    if (finalQuery.length < 3) {
      finalQuery += ' news';
    }
  }

  let mapSrc = `https://maps.google.com/maps?q=${encodeURIComponent(finalQuery)}&t=&z=14&ie=UTF8&iwloc=&output=embed`;

  // ── STEP 3: Weather widget ──
  let weatherInnerHtml = `<span style="font-size:12px;color:var(--text3);">📍 ${escapeHtml(locLabel)}</span>`;
  if (lat && lon) {
    try {
      const wRes = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&hourly=relativehumidity_2m&windspeed_unit=kmh`);
      const wData = await wRes.json();
      if (wData?.current_weather) {
        const wc = wData.current_weather;
        const icons = ['☀️','🌤️','⛅','🌧️','🌩️','❄️'];
        const icon = wc.weathercode <= 1 ? icons[0] : wc.weathercode <= 3 ? icons[1] : wc.weathercode <= 48 ? icons[2] : wc.weathercode <= 67 ? icons[3] : wc.weathercode <= 77 ? icons[5] : icons[4];
        
        const accuracyWarning = gpsDenied ? `<div style="font-size:10px;color:var(--red);margin-top:4px;font-weight:600;background:rgba(255,0,0,0.1);padding:2px 4px;border-radius:4px;display:inline-block;">⚠️ GPS Blocked. Showing Network IP Location.</div>` : ``;

        weatherInnerHtml = `
          <span style="font-size:22px;line-height:1;">${icon}</span>
          <div>
            <div style="font-weight:700;font-size:16px;color:var(--text);">${wc.temperature}°C</div>
            <div style="font-size:11px;color:var(--text3);">💨 ${wc.windspeed} km/h · 📍 ${escapeHtml(locLabel)}</div>
            ${accuracyWarning}
          </div>`;
      }
    } catch(_) {}
  }

  // ── STEP 4: Category chips ──
  const categories = [
    {emoji:'🍔',label:'Restaurants',q:'Restaurants'},
    {emoji:'☕',label:'Cafes',q:'Cafes'},
    {emoji:'🏨',label:'Hotels',q:'Hotels'},
    {emoji:'🏥',label:'Hospitals',q:'Hospitals'},
    {emoji:'💊',label:'Pharmacies',q:'Pharmacies'},
    {emoji:'🏧',label:'ATMs',q:'ATMs'},
    {emoji:'🛒',label:'Shopping',q:'Shopping Malls'},
    {emoji:'⛽',label:'Petrol',q:'Petrol Pumps'},
    {emoji:'🚌',label:'Transit',q:'Bus Stop'},
    {emoji:'🎭',label:'Museums',q:'Museums'},
  ];

  const nearPrefix = lat ? `${lat},${lon}` : locLabel;
  const chipBar = `<div style="display:flex;gap:8px;overflow-x:auto;padding:12px 14px;scrollbar-width:none;background:var(--surface);border-bottom:1px solid var(--border);">
    ${categories.map(c => `
      <button onclick="renderMapPlaces('${c.q} near ${nearPrefix}')"
              style="padding:7px 14px;background:var(--bg3);border:1px solid var(--border);border-radius:20px;color:var(--text);cursor:pointer;font-size:12px;font-weight:600;white-space:nowrap;flex-shrink:0;transition:all 0.2s;"
              onmouseover="this.style.background='var(--accent)';this.style.color='#000';this.style.borderColor='var(--accent)'"
              onmouseout="this.style.background='var(--bg3)';this.style.color='var(--text)';this.style.borderColor='var(--border)'"
      >${c.emoji} ${c.label}</button>`).join('')}
  </div>`;

  // ── STEP 5: Map view mode controls ──
  // ── STEP 5: Map view mode controls ──
  const viewModes = `
    <style>
      @media (max-width: 600px) {
        #map-controls-bottom { bottom: 10px !important; gap: 4px !important; }
        #map-controls-bottom button { padding: 4px 8px !important; font-size: 10px !important; }
        #weather-widget-container { top: 10px !important; right: 10px !important; }
        #weather-widget { padding: 6px 10px !important; gap: 6px !important; }
        #weather-widget span { font-size: 16px !important; }
        #weather-widget div { font-size: 12px !important; }
      }
    </style>
    <div id="map-controls-bottom" style="position:absolute;bottom:24px;left:50%;transform:translateX(-50%);z-index:10;display:flex;gap:8px;flex-wrap:wrap;justify-content:center;width:max-content;max-width:95vw;">
      ${['Satellite','Terrain','Traffic'].map((mode, i) => `
        <button onclick="switchMapMode('${mode.toLowerCase()}','${encodeURIComponent(finalQuery)}',${lat||0},${lon||0})"
                id="map-mode-${mode.toLowerCase()}"
                style="padding:6px 12px;background:rgba(10,10,10,0.85);border:1px solid rgba(255,255,255,0.15);color:#fff;border-radius:16px;cursor:pointer;font-size:11px;font-weight:600;backdrop-filter:blur(8px);transition:all 0.2s;"
                onmouseover="this.style.background='var(--accent)';this.style.color='#000'"
                onmouseout="this.style.background='rgba(10,10,10,0.85)';this.style.color='#fff'"
        >${['🛰','🏔','🚦'][i]} ${mode}</button>`).join('')}
    </div>
    <div id="weather-widget-container" style="position:absolute;top:14px;right:14px;z-index:10;">
      <div style="background:rgba(10,10,10,0.85);border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:10px 14px;display:flex;align-items:center;gap:10px;backdrop-filter:blur(10px);" id="weather-widget">
        ${weatherInnerHtml}
      </div>
    </div>`;

  el.innerHTML = `
    ${chipBar}
    <div style="position:relative;border-radius:0 0 var(--radius-lg) var(--radius-lg);overflow:hidden;" id="map-frame-container">
      ${viewModes}
      <iframe id="blend-map-iframe" width="100%" height="580"
              style="border:0;display:block;filter:invert(90%) hue-rotate(180deg) contrast(1.05) saturate(1.2);"
              loading="lazy" allowfullscreen
              src="${mapSrc}"></iframe>
    </div>
    <div id="map-results-list" style="margin-top:12px;"></div>`;

  // ── STEP 6: Load text results ──
  try {
    const searchQ = (lat && lon) ? `${q} near ${lat},${lon}` : finalQuery;
    const res = await fetch(API(`/api/search?q=${encodeURIComponent(searchQ)}&categories=map&format=json`));
    const data = await res.json();
    const listEl = document.getElementById('map-results-list');
    if (data.results?.length) {
      window.SECTION_CACHE['maps'] = data.results;
      listEl.innerHTML = `<p style="font-size:12px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;">📍 Nearby Places</p>` +
        data.results.slice(0, 8).map(p => `
          <div style="display:flex;gap:12px;align-items:flex-start;padding:12px;border:1px solid var(--border);border-radius:12px;margin-bottom:8px;background:var(--surface);transition:all 0.2s;"
               onmouseover="this.style.borderColor='rgba(0,201,167,0.4)'" onmouseout="this.style.borderColor='var(--border)'">
            <div style="width:36px;height:36px;background:var(--bg3);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">📍</div>
            <div style="min-width:0;flex:1;">
              <a href="${p.url}" target="${LINK_TARGET}" style="font-size:14px;font-weight:600;color:var(--link);text-decoration:none;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${escapeHtml(p.title)}</a>
              ${p.content ? `<div style="font-size:12px;color:var(--text3);margin-top:2px;line-height:1.4;">${escapeHtml(p.content.slice(0,120))}</div>` : ''}
            </div>
          </div>`).join('');
    } else {
      listEl.innerHTML = '';
    }
  } catch(_) {}
}

function switchMapMode(mode, encodedQ, lat, lon) {
  const iframe = document.getElementById('blend-map-iframe');
  if (!iframe) return;
  const typeMap = { satellite: 'k', terrain: 'p', traffic: '' };
  const t = typeMap[mode] || '';
  const query = decodeURIComponent(encodedQ);
  let src = `https://maps.google.com/maps?q=${encodeURIComponent(query)}&t=${t}&z=14&ie=UTF8&iwloc=&output=embed`;
  iframe.src = src;
}

async function renderMusic(q) {
  const el = document.getElementById('music-list');
  const searchQ = q || 'Top Trending Music';
  el.innerHTML = `<div style="padding:40px;text-align:center;color:var(--text3);"><div class="loading-spinner" style="margin:0 auto 16px;"></div><div>Loading ${q ? `music for "<strong>${escapeHtml(searchQ)}</strong>"` : '🔥 Real-time Trending Music'}...</div></div>`;
  try {
    const res = await fetch(API(`/api/search?q=${encodeURIComponent(searchQ)}&categories=music&format=json`));
    if (!res.ok) throw new Error('API Error ' + res.status);
    const data = await res.json();
    if (data.results && data.results.length > 0) {
      window.SECTION_CACHE['music'] = data.results;
      window.MUSIC_QUEUE = data.results.map(m => ({
        title: m.title,
        url: m.url,
        id: m.id || extractYtId(m.url),
        thumbnail: m.thumbnail,
        author: m.author,
        duration: m.duration,
        views: m.views
      }));

      const headerHtml = !q
        ? `<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;"><span style="font-size:22px;font-weight:800;color:var(--text);">🔥 Trending Now</span><span style="font-size:12px;font-weight:600;background:linear-gradient(135deg,#ff416c,#ff4b2b);color:#fff;padding:3px 10px;border-radius:20px;letter-spacing:0.5px;">LIVE</span></div>`
        : `<div style="font-size:16px;font-weight:700;color:var(--text2);margin-bottom:10px;">🎵 Results for "${escapeHtml(searchQ)}"</div>`;

      const searchUI = `<div style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:16px;margin-bottom:24px;display:flex;gap:10px;align-items:center;box-shadow:0 4px 12px rgba(0,0,0,0.1);">
          <input type="text" id="music-universal-input" placeholder="Paste any Video/Audio URL (YouTube, FB, Insta...) or search a song..." 
                 style="flex:1;background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:12px 16px;color:var(--text);font-size:14px;outline:none;"
                 onkeydown="if(event.key==='Enter') renderMusic(this.value);" />
          <button onclick="renderMusic(document.getElementById('music-universal-input').value)" 
                  style="background:var(--accent);color:#000;border:none;padding:12px 24px;border-radius:8px;font-weight:700;cursor:pointer;transition:transform 0.2s;"
                  onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='none'">Search / DL</button>
      </div>`;

      el.innerHTML = searchUI + headerHtml + `<div id="music-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px;">` +
        data.results.map((m, idx) => {
          const ytId = m.id || extractYtId(m.url);
          const thumb = m.thumbnail || (ytId ? `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg` : '');
          return `
          <div onclick="playYouTubeModal('${ytId}','${escapeJs(m.title)}','${escapeJs(m.url)}')"
               style="background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;cursor:pointer;
                      animation:slideIn 0.4s cubic-bezier(0.16,1,0.3,1) ${idx*0.04}s both;
                      transition:transform 0.2s,box-shadow 0.2s,border-color 0.2s;"
               onmouseover="this.style.transform='translateY(-6px)';this.style.boxShadow='0 16px 32px rgba(0,0,0,0.5)';this.style.borderColor='rgba(0,201,167,0.4)'"
               onmouseout="this.style.transform='none';this.style.boxShadow='none';this.style.borderColor='var(--border)'">

            <div style="position:relative;aspect-ratio:16/9;background:#0a0a0a;overflow:hidden;">
              ${thumb ? `<img src="${thumb}" loading="lazy" decoding="async"
                          style="width:100%;height:100%;object-fit:cover;display:block;"
                          onerror="this.parentElement.style.background='#111';this.remove()" />` : ''}
              <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,0.6) 0%,transparent 60%);"></div>
              <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity 0.2s;"
                   onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0'">
                <div style="width:52px;height:52px;background:rgba(0,201,167,0.9);border-radius:50%;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="#000"><path d="M8 5v14l11-7z"/></svg>
                </div>
              </div>
              ${m.duration ? `<div style="position:absolute;bottom:6px;right:8px;background:rgba(0,0,0,0.85);color:#fff;font-size:11px;font-weight:700;padding:2px 7px;border-radius:5px;">${m.duration}</div>` : ''}
            </div>

            <div style="padding:12px 14px;">
              <div style="font-size:13px;font-weight:700;color:var(--text);line-height:1.4;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;margin-bottom:6px;">${escapeHtml(m.title)}</div>
              <div style="font-size:12px;color:var(--text3);margin-bottom:10px;">${escapeHtml(m.author || 'Artist')}</div>
              <div style="display:flex;justify-content:space-between;align-items:center;">
                <span style="font-size:11px;color:var(--text3);">${m.views ? '👁 ' + m.views : ''}</span>
                <button onclick="downloadMusic('${escapeJs(m.url)}');event.stopPropagation();"
                        style="background:var(--surface2);border:1px solid var(--border);color:var(--text2);padding:4px 12px;border-radius:20px;cursor:pointer;font-size:11px;font-weight:600;
                               transition:all 0.2s;"
                        onmouseover="this.style.background='var(--accent)';this.style.color='#000';this.style.borderColor='var(--accent)'"
                        onmouseout="this.style.background='var(--surface2)';this.style.color='var(--text2)';this.style.borderColor='var(--border)'">
                  ↓ MP3
                </button>
              </div>
            </div>
          </div>`;
        }).join('') + `</div>
        <div style="text-align:center;margin-top:20px;">
          <button onclick="renderMusicMore('${escapeJs(searchQ)}', ${data.results.length})"
                  id="music-load-more"
                  style="padding:10px 32px;background:var(--surface);border:1px solid var(--border);color:var(--text);
                         border-radius:24px;cursor:pointer;font-size:13px;font-weight:600;transition:all 0.2s;"
                  onmouseover="this.style.borderColor='var(--accent)';this.style.color='var(--accent)'"
                  onmouseout="this.style.borderColor='var(--border)';this.style.color='var(--text)'">
            Load More Results
          </button>
        </div>`;
      return;
    }
  } catch (e) {
    console.error('Music fetch error:', e);
  }
  el.innerHTML = emptyState('🎵', `No music results for "${searchQ}"`, 'Check backend connection or try a different song.', `renderMusic('${escapeJs(searchQ)}')`);
}

async function renderMusicMore(q, offset) {
  const btn = document.getElementById('music-load-more');
  const grid = document.getElementById('music-grid');
  if (!btn || !grid) return;
  btn.textContent = 'Loading…';
  btn.disabled = true;
  try {
    const res = await fetch(API(`/api/search?q=${encodeURIComponent(q + ' more songs')}&categories=music&format=json`));
    const data = await res.json();
    if (data.results?.length) {
      data.results.forEach((m, idx) => {
        const ytId = m.id || extractYtId(m.url);
        const thumb = m.thumbnail || (ytId ? `https://i.ytimg.com/vi/${ytId}/hqdefault.jpg` : '');
        const card = document.createElement('div');
        card.onclick = () => playYouTubeModal(ytId, m.title, m.url);
        card.style.cssText = `background:var(--surface);border:1px solid var(--border);border-radius:14px;overflow:hidden;cursor:pointer;transition:transform 0.2s,box-shadow 0.2s,border-color 0.2s;animation:slideIn 0.4s cubic-bezier(0.16,1,0.3,1) ${idx*0.04}s both;`;
        card.onmouseover = () => { card.style.transform='translateY(-6px)';card.style.boxShadow='0 16px 32px rgba(0,0,0,0.5)';card.style.borderColor='rgba(0,201,167,0.4)'; };
        card.onmouseout = () => { card.style.transform='none';card.style.boxShadow='none';card.style.borderColor='var(--border)'; };
        card.innerHTML = `
          <div style="position:relative;aspect-ratio:16/9;background:#0a0a0a;overflow:hidden;">
            ${thumb ? `<img src="${thumb}" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;" onerror="this.remove()"/>` : ''}
            <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,0.5),transparent);"></div>
            ${m.duration ? `<div style="position:absolute;bottom:6px;right:8px;background:rgba(0,0,0,0.85);color:#fff;font-size:11px;font-weight:700;padding:2px 7px;border-radius:5px;">${m.duration}</div>` : ''}
          </div>
          <div style="padding:12px 14px;">
            <div style="font-size:13px;font-weight:700;color:var(--text);line-height:1.4;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;margin-bottom:4px;">${escapeHtml(m.title)}</div>
            <div style="font-size:11px;color:var(--text3);">${escapeHtml(m.author || 'Artist')} ${m.views ? '· 👁 '+m.views : ''}</div>
          </div>`;
        grid.appendChild(card);
      });
      btn.textContent = 'Load More Results';
      btn.disabled = false;
    } else {
      btn.textContent = 'No more results';
    }
  } catch(_) {
    btn.textContent = 'Failed — Retry';
    btn.disabled = false;
  }
}

async function downloadMusic(url, quality = 'best') {
  // Use the native backend yt-dlp processor for reliable downloading
  const newTab = window.open('', '_blank');
  if(newTab) newTab.document.write('<body style="background:#0a0a0a;color:#fff;font-family:sans-serif;display:flex;flex-direction:column;justify-content:center;align-items:center;height:100vh;margin:0;"><h2 style="margin-bottom:10px;">Generating native download link...</h2><p style="color:#aaa;font-size:14px;">Please wait while we process the highest quality stream for you.</p></body>');

  try {
    const dlUrl = API(`/api/smart_download?url=${encodeURIComponent(url)}&quality=${encodeURIComponent(quality)}`);
    if(newTab) newTab.location.href = dlUrl;
    else window.location.href = dlUrl;
  } catch (err) {
    if(newTab) newTab.document.write('<body style="background:#0a0a0a;color:#ff4444;font-family:sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;"><h2>Network Error. Check backend.</h2></body>');
  }
}

async function renderFiles(q, engineFilter = '') {
  const el = document.getElementById('files-list');
  const statsEl = document.getElementById('files-stats');
  showDeepSearchPending('files', q);
  
  el.innerHTML = '<div style="padding:40px;text-align:center;grid-column:1/-1;color:var(--text3);"><span style="display:inline-block;animation:pulse 1s infinite;">🔍 Fetching Open-Web Documents...</span></div>';
  statsEl.innerText = selectedSearchMode() === 'deep' ? 'Crawl4AI deep-searching document sources...' : 'Searching open web...';
  
  try {
    const params = new URLSearchParams({ categories: 'files', format: 'json' });
    applySearchModeParam(params);
    let searchQ = q;
    if (engineFilter && engineFilter !== 'all') {
      if (engineFilter === 'pdf') {
        searchQ = q + ' filetype:pdf';
      } else {
        params.set('engines', engineFilter);
      }
    }
    params.set('q', searchQ);
    
    if (window.LANG_PARAM) params.set('language', window.LANG_PARAM.replace('&language=', ''));
    
    const startTime = performance.now();
    const res = await fetch(API(`/api/search?${params.toString()}`));
    if (!res.ok) throw new Error('API Error');
    const data = await res.json();
    updateDeepSearchPanel(data, 'files');
    const timeTaken = ((performance.now() - startTime) / 1000).toFixed(2);
    
    if (data.results && data.results.length > 0) {
      statsEl.innerHTML = `Found ${data.number_of_results || data.results.length} files/documents (${timeTaken} seconds) <span style="font-size:10px;color:var(--accent);border:1px solid var(--accent);border-radius:10px;padding:2px 6px;margin-left:8px;">${searchModeLabel(selectedSearchMode())}</span>`;
      
      const fileExtRegex = /\.(pdf|docx?|xlsx?|pptx?|txt|csv|json|md|py|js|html)$/i;
      
      window.SECTION_CACHE['files'] = data.results;
      el.innerHTML = data.results.map((r, idx) => {
        let domain = r.parsed_url ? r.parsed_url[1].replace('www.', '') : (r.source || 'File');
        let extMatch = r.url.match(fileExtRegex);
        let fileType = extMatch ? extMatch[1].toUpperCase() : '';
        
        let icon = '📄';
        if (domain.includes('github.com')) { icon = '🐙'; fileType = fileType || 'REPO'; }
        else if (domain.includes('reddit.com')) { icon = '🤖'; fileType = fileType || 'THREAD'; }
        else if (domain.includes('wikipedia.org')) { icon = '📖'; fileType = fileType || 'WIKI'; }
        else if (domain.includes('readthedocs') || domain.includes('docs.')) { icon = '📑'; fileType = fileType || 'DOCS'; }
        else if (domain.includes('readxhub.in')) { icon = '📚'; fileType = fileType || 'ARTICLE'; }
        else if (fileType === 'PDF') icon = '📕';
        else if (fileType === 'TXT' || fileType === 'MD') icon = '📝';
        else if (fileType === 'JSON' || fileType === 'CSV') icon = '📊';
        else if (['PY', 'JS', 'HTML'].includes(fileType)) icon = '💻';
        
        if (!fileType) fileType = 'WEB';
        
        let filesize = r.filesize ? `<span style="background:var(--bg);padding:2px 6px;border-radius:4px;font-size:10px;">${(r.filesize/1024/1024).toFixed(1)} MB</span>` : '';
        
        return `
        <div style="display:flex;flex-direction:column;padding:16px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);transition:all 0.2s;animation: slideIn 0.3s ease ${idx * 0.05}s;" onmouseover="this.style.borderColor='var(--border2)';this.style.transform='translateY(-2px)';" onmouseout="this.style.borderColor='var(--border)';this.style.transform='none';">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
            <div style="width:36px;height:36px;background:var(--bg);border:1px solid var(--border2);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px;">${icon}</div>
            <div style="overflow:hidden;">
              <div style="font-size:11px;font-weight:700;color:var(--text3);text-transform:uppercase;letter-spacing:0.5px;display:flex;gap:6px;align-items:center;">
                ${domain} 
                <span style="background:var(--accent-glow);color:var(--accent);padding:2px 6px;border-radius:4px;font-size:9px;">${fileType}</span>
                ${filesize}
                ${deepResultBadge(r)}
              </div>
            </div>
            <a href="${r.url}" target="${LINK_TARGET}" style="margin-left:auto;padding:6px 12px;background:var(--accent);color:#000;border-radius:12px;font-size:11px;font-weight:700;text-decoration:none;transition:transform 0.1s;">Open ↗</a>
          </div>
          <h3 style="font-size:15px;font-weight:600;margin-bottom:8px;line-height:1.4;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;color:var(--link);">
            <a href="${r.url}" target="${LINK_TARGET}" style="color:inherit;text-decoration:none;">${r.title}</a>
          </h3>
          <p style="font-size:13px;color:var(--text2);line-height:1.5;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;">${r.content || 'No preview available.'}</p>
          ${r.deep_content ? `<p style="font-size:12px;color:var(--text2);line-height:1.5;border-left:2px solid var(--accent);padding-left:10px;margin-top:10px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;">${escapeHtml(deepTextPreview(r.deep_content, 260))}</p>` : ''}
        </div>`;
      }).join('');
      return;
    }
  } catch (e) {
    console.log('File search failed:', e);
  }
  statsEl.innerText = '0 results found';
  el.innerHTML = emptyState('📂', 'No relevant files or documents found', 'Try refining your query, switching sources, or dropping file extensions.', `renderFiles('${escapeJs(q)}', '${engineFilter}')`);
}

function filterFiles(engine) {
  const btns = document.querySelectorAll('.file-filter-btn');
  btns.forEach(btn => {
    btn.classList.remove('active');
    btn.style.background = 'transparent';
    btn.style.color = 'var(--text2)';
    btn.style.fontWeight = '500';
  });
  const activeBtn = Array.from(btns).find(b => b.getAttribute('onclick').includes(engine));
  if (activeBtn) {
    activeBtn.classList.add('active');
    activeBtn.style.background = 'var(--accent)';
    activeBtn.style.color = '#000';
    activeBtn.style.fontWeight = '600';
  }
  
  const q = document.getElementById('top-search')?.value?.trim() || sessionStorage.getItem('blend_q') || new URLSearchParams(window.location.search).get('q') || '';
  renderFiles(q, engine);
}


async function renderSocial(q) {
  const el = document.getElementById('social-list');
  showDeepSearchPending('social', q);
  el.innerHTML = '<div style="padding:20px;text-align:center;color:var(--text3);">👥 ' + (selectedSearchMode() === 'deep' ? 'Crawl4AI deep-searching social sources about ' : 'Loading social posts about ') + '"<strong>' + q + '</strong>"...</div>';
  try {
    let searchQ = q;
    const params = new URLSearchParams({ q: searchQ, categories: 'social media', format: 'json' });
    applySearchModeParam(params);
    if (window.LANG_PARAM) params.set('language', window.LANG_PARAM.replace('&language=', ''));
    const res = await fetch(API(`/api/search?${params.toString()}`));
    if (!res.ok) throw new Error('API Error');
    const data = await res.json();
    updateDeepSearchPanel(data, 'social');
    if (data.results && data.results.length > 0) {
      const results = boostByUrl(q, data.results);
      window.SECTION_CACHE['social'] = results;
      const platformColors = { 'reddit':'#ff6314', 'twitter':'#1da1f2', 'mastodon':'#6364ff', 'github':'#333', 'facebook':'#4267b2', 'linkedin':'#0077b5', 'dev.to':'#0a0a0a' };
      el.innerHTML = results.map((s, idx) => {
        let domain = s.parsed_url ? s.parsed_url[1] : (s.engine || s.source || 'Social');
        const plat = domain.replace('www.', '').toLowerCase();
        const pColor = platformColors[plat] || '#888';
        return `
        <div style="padding:14px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius-lg);margin-bottom:10px;animation: slideIn 0.3s ease ${idx * 0.05}s;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
            <span style="font-size:11px;font-weight:700;padding:2px 8px;border-radius:4px;background:${pColor}22;color:${pColor};border:1px solid ${pColor}44;text-transform:capitalize;">${plat}</span>
            ${deepResultBadge(s)}
            <a href="${s.url}" target="${LINK_TARGET}" style="font-size:12px;color:var(--link);text-decoration:none;margin-left:auto;">View ↗</a>
          </div>
          <p style="font-size:14px;color:var(--text);line-height:1.55;">${s.content || s.title}</p>
          ${s.deep_content ? `<p style="font-size:12px;color:var(--text2);line-height:1.5;border-left:2px solid var(--accent);padding-left:10px;margin-top:8px;">${escapeHtml(deepTextPreview(s.deep_content, 220))}</p>` : ''}
        </div>`;
      }).join('');
      return;
    }
  } catch (e) { 
    console.log('Backend social failed', e);
  }
  el.innerHTML = emptyState('👥', `No social results for "${q}"`, 'Try a username, brand name, or add a social platform keyword.', `renderSocial('${escapeJs(q)}')`);
}

/* ── TAB SWITCHING ── */
function switchTab(tab, btn) {
  document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('tab-'+tab).style.display = 'block';
  const activeBtn = btn || document.querySelector(`.tab-btn[data-tab="${tab}"]`);
  if (activeBtn) activeBtn.classList.add('active');
  const url = new URL(window.location);
  url.searchParams.set('tab', tab);
  history.replaceState({}, '', url);

  const q = document.getElementById('top-search')?.value?.trim() || new URLSearchParams(window.location.search).get('q') || sessionStorage.getItem('blend_q') || '';
  if (!q) return;
  if (tab === 'web' && !window.CURRENT_RESULTS?.length) renderWeb(q);
  if (tab === 'images' && !window.allImages?.length) renderImages(q);
  if (tab === 'videos' && !document.getElementById('full-videos').dataset.loaded) { document.getElementById('full-videos').dataset.loaded = '1'; renderVideos(q); }
  if (tab === 'news' && !document.getElementById('news-list').dataset.loaded) { document.getElementById('news-list').dataset.loaded = '1'; renderNews(q); }
  if (tab === 'maps' && !document.getElementById('map-places').dataset.loaded) { document.getElementById('map-places').dataset.loaded = '1'; renderMapPlaces(q); }
  if (tab === 'music' && !document.getElementById('music-list').dataset.loaded) { document.getElementById('music-list').dataset.loaded = '1'; renderMusic(q); }
  if (tab === 'files' && !document.getElementById('files-list').dataset.loaded) { document.getElementById('files-list').dataset.loaded = '1'; renderFiles(q); }
  if (tab === 'social' && !document.getElementById('social-list').dataset.loaded) { document.getElementById('social-list').dataset.loaded = '1'; renderSocial(q); }
}

/* ── LIGHTBOX ── */
function openLightbox(src, label) {
  document.getElementById('lightbox-img').src = src;
  document.getElementById('lightbox-meta').textContent = label;
  document.getElementById('lightbox').classList.add('open');
}
function closeLightbox(e) {
  if (!e || e.target === document.getElementById('lightbox') || e.target.classList.contains('lightbox-close')) {
    document.getElementById('lightbox').classList.remove('open');
  }
}

async function fallbackPipedApi(ytId, type = 'video') {
  const apis = ['https://pipedapi.kavin.rocks', 'https://pipedapi.ducks.party', 'https://api.piped.private.coffee', 'https://piped-api.lunar.icu'];
  for (const api of apis) {
    try {
      const res = await fetch(`${api}/streams/${ytId}`, { signal: AbortSignal.timeout(4000) });
      if (res.ok) {
        const data = await res.json();
        let streams = type === 'audio' ? data.audioStreams : (data.videoStreams || []);
        if (streams && streams.length > 0 && streams[0].url) {
          return streams[0].url;
        }
        if (data.audioStreams && data.audioStreams.length > 0 && data.audioStreams[0].url) {
          return data.audioStreams[0].url;
        }
      }
    } catch(e) { console.warn(`Fallback ${api} failed`); }
  }
  return null;
}

/* ── VIDEO MODAL & DOWNLOADS ── */
window.CURRENT_VIDEO_URL = '';
function openVideo(ytId, title, url) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-iframe').src = ytId ? `https://www.youtube.com/embed/${ytId}?autoplay=1` : url;
  window.CURRENT_VIDEO_URL = url || `https://youtube.com/watch?v=${ytId}`;
  document.getElementById('video-modal').classList.add('open');
}

/* ── YOUTUBE MUSIC THEATER MODAL ── */
/* ═══════════════════════════════════════════
   BLEND PROFESSIONAL MEDIA PLAYER
   Uses yt-dlp backend to extract real stream
   URLs — plays in HTML5 <video> element
   ═══════════════════════════════════════════ */

window.BLEND_PLAYER = { url: null, ytId: null, title: null };

function playYouTubeModal(ytId, title, url) {
  window.BLEND_PLAYER = { url, ytId, title };

  const old = document.getElementById('blend-player-modal');
  if (old) old.remove();

  // Build modal shell immediately — show loading state
  const modal = document.createElement('div');
  modal.id = 'blend-player-modal';
  modal.style.cssText = `position:fixed;inset:0;background:#000;z-index:9999;
    display:flex;flex-direction:column;align-items:center;
    overflow-y:auto;box-sizing:border-box;animation:fadeIn 0.2s ease;`;

  const thumb = ytId ? `https://i.ytimg.com/vi/${ytId}/maxresdefault.jpg` : '';

  modal.innerHTML = `
    <!-- TOP BAR -->
    <div id="bp-topbar" style="width:100%;max-width:1100px;display:flex;align-items:center;gap:10px;padding:14px 20px;box-sizing:border-box;flex-shrink:0;">
      <!-- URL INPUT -->
      <div style="flex:1;display:flex;align-items:center;background:#111;border:1px solid #2a2a2a;border-radius:8px;padding:0 14px;gap:8px;height:42px;">
        <svg width="13" height="13" fill="#555" viewBox="0 0 24 24"><path d="M10 2a8 8 0 100 16A8 8 0 0010 2zm12 12l-4.35-4.35A7.96 7.96 0 0018 10a8 8 0 10-8 8 7.96 7.96 0 004.65-1.35L19 21l3-3z"/></svg>
        <input id="bp-url-input" type="text" placeholder="Paste YouTube URL or search term…"
               value="${escapeHtml(url || '')}"
               style="flex:1;background:none;border:none;outline:none;color:#e0e0e0;font-size:13px;font-family:inherit;"
               onkeydown="if(event.key==='Enter'){ event.preventDefault(); blendPlayerLoad(); }"/>
      </div>
      <button onclick="blendPlayerLoad()"
              style="background:#00c9a7;color:#000;border:none;height:42px;padding:0 20px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;white-space:nowrap;flex-shrink:0;letter-spacing:0.3px;">
        ▶ Play
      </button>
      <button onclick="document.getElementById('blend-player-modal').remove()"
              style="background:#1c1c1c;border:1px solid #2a2a2a;color:#888;width:42px;height:42px;border-radius:8px;cursor:pointer;font-size:20px;flex-shrink:0;display:flex;align-items:center;justify-content:center;">✕</button>
    </div>

    <!-- MAIN CONTENT AREA -->
    <div id="bp-main" style="width:100%;max-width:1100px;display:flex;flex-direction:column;padding:0 20px 30px;box-sizing:border-box;gap:16px;flex:1;">

      <!-- VIDEO PLAYER -->
      <div id="bp-video-container" style="position:relative;width:100%;background:#000;border-radius:10px;overflow:hidden;aspect-ratio:16/9;">
        <!-- Loading state (blurred thumbnail) -->
        <div id="bp-loading" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;background:#0a0a0a;z-index:2;">
          ${thumb ? `<img src="${thumb}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:0.15;filter:blur(8px);" onerror="this.remove()"/>` : ''}
          <div style="position:relative;z-index:1;display:flex;flex-direction:column;align-items:center;gap:14px;">
            <div id="bp-spinner" style="width:42px;height:42px;border:3px solid rgba(255,255,255,0.1);border-top-color:#00c9a7;border-radius:50%;animation:blendSpin 0.8s linear infinite;"></div>
            <div id="bp-status" style="color:#888;font-size:13px;letter-spacing:0.3px;">Extracting stream…</div>
          </div>
        </div>
        <!-- HTML5 Video Element -->
        <video id="bp-video" style="width:100%;height:100%;display:none;background:#000;"
               controls playsinline preload="metadata"
               controlslist="nodownload">
          <source src="" type="video/mp4"/>
        </video>

        <!-- CUSTOM QUALITY OVERLAY (The Three Dots Menu) -->
        <div style="position:absolute;top:16px;right:16px;z-index:10;">
          <button onclick="const m = document.getElementById('bp-quality-menu'); m.style.display = m.style.display==='none'?'block':'none';"
                  style="background:rgba(0,0,0,0.6);border:1px solid rgba(255,255,255,0.1);color:#fff;width:36px;height:36px;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;backdrop-filter:blur(4px);transition:0.2s;"
                  onmouseover="this.style.background='rgba(0,0,0,0.8)'" onmouseout="this.style.background='rgba(0,0,0,0.6)'" title="Video Settings">
            <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
          </button>
          
          <div id="bp-quality-menu" style="display:none;position:absolute;top:44px;right:0;background:rgba(15,15,15,0.95);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px;backdrop-filter:blur(10px);min-width:140px;box-shadow:0 10px 30px rgba(0,0,0,0.8);">
            <div style="font-size:11px;color:#aaa;padding:4px 8px;margin-bottom:6px;border-bottom:1px solid rgba(255,255,255,0.1);letter-spacing:0.5px;">PLAYBACK QUALITY</div>
            <div id="bp-quality-btns" style="display:flex;flex-direction:column;gap:4px;"></div>
          </div>
        </div>
      </div>

      <!-- METADATA ROW -->
      <div id="bp-meta" style="display:flex;flex-direction:column;gap:10px;">
        <div id="bp-title" style="font-size:19px;font-weight:700;color:#f0f0f0;line-height:1.3;">${escapeHtml(title)}</div>
        <div id="bp-info-row" style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
          <span id="bp-channel" style="font-size:13px;color:#00c9a7;font-weight:600;"></span>
          <span id="bp-views" style="font-size:12px;color:#666;"></span>
          <span id="bp-date" style="font-size:12px;color:#666;"></span>
          <span id="bp-duration-meta" style="font-size:12px;color:#666;"></span>
          <a id="bp-yt-link" href="${url || '#'}" target="${LINK_TARGET}" rel="noopener"
             style="font-size:12px;color:#555;text-decoration:none;margin-left:auto;display:flex;align-items:center;gap:5px;white-space:nowrap;"
             onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#555'">
            <svg width="13" height="13" fill="currentColor" viewBox="0 0 24 24"><path d="M21 3L3 10.53v.98l6.84 2.65L12.48 21h.98L21 3z"/></svg>
            Watch on YouTube
          </a>
        </div>
      </div>

      <!-- DOWNLOAD BAR -->
      <div id="bp-action-bar" style="background:#0e0e0e;border:1px solid #1e1e1e;border-radius:10px;padding:14px 18px;display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
        <span style="font-size:12px;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:0.8px;flex-shrink:0;">
          <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24" style="vertical-align:-2px;margin-right:4px;"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
          Download
        </span>
        
        <select id="bp-dl-format" onchange="const q = document.getElementById('bp-dl-quality'); if(this.value==='audio') { q.disabled=true; q.style.opacity=0.5; } else { q.disabled=false; q.style.opacity=1; }" style="background:#1c1c1c;color:#fff;border:1px solid #333;padding:8px 12px;border-radius:6px;font-size:12px;outline:none;cursor:pointer;font-weight:600;">
          <option value="video">MP4 (Video)</option>
          <option value="audio">MP3 (Audio)</option>
        </select>
        
        <select id="bp-dl-quality" style="background:#1c1c1c;color:#fff;border:1px solid #333;padding:8px 12px;border-radius:6px;font-size:12px;outline:none;cursor:pointer;font-weight:600;">
          <option value="360p">360p</option>
          <option value="720p">720p</option>
          <option value="1080p">1080p</option>
          <option value="4k">4K</option>
        </select>

        <button onclick="downloadMusic(window.BLEND_PLAYER.url, document.getElementById('bp-dl-format').value === 'audio' ? 'audio' : document.getElementById('bp-dl-quality').value)"
                style="background:#00c9a7;color:#000;border:none;padding:9px 24px;border-radius:6px;font-size:12px;font-weight:800;cursor:pointer;margin-left:auto;transition:0.2s;text-transform:uppercase;letter-spacing:0.5px;"
                onmouseover="this.style.background='#00b093'" onmouseout="this.style.background='#00c9a7'">
          ⬇ Download
        </button>
      </div>

      <!-- ERROR STATE (hidden by default) -->
      <div id="bp-error" style="display:none;padding:20px;background:#130a0a;border:1px solid #3a1515;border-radius:10px;text-align:center;">
        <div style="font-size:14px;color:#ff7070;margin-bottom:14px;" id="bp-error-msg">Stream extraction failed.</div>
        <div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
          <a id="bp-yt-fallback" href="${url || '#'}" target="${LINK_TARGET}"
             style="background:#ff0000;color:#fff;padding:10px 24px;border-radius:8px;text-decoration:none;font-size:13px;font-weight:700;display:flex;align-items:center;gap:6px;">
            <svg width="14" height="14" fill="white" viewBox="0 0 24 24"><path d="M21.8 8S21.6 6.3 20.9 5.6c-.7-.8-1.5-.8-1.8-.8C16.4 4.6 12 4.6 12 4.6s-4.4 0-7.1.2c-.4 0-1.2 0-1.8.8-.7.7-.9 2.3-.9 2.3S2 9.9 2 11.9v1.9c0 1.9.2 3.8.2 3.8s.2 1.7.9 2.3c.7.8 1.6.7 2 .8C6.8 20 12 20 12 20s4.4 0 7.1-.2c.4 0 1.2 0 1.8-.8.7-.7.9-2.3.9-2.3s.2-1.9.2-3.8v-1.9C22 9.9 21.8 8 21.8 8zM9.8 15V9l6 3-6 3z"/></svg>
            Open YouTube
          </a>
        </div>
      </div>

    </div>
  `;

  // Close on backdrop (very edge of modal)
  modal.addEventListener('click', e => { if (e.target === modal) modal.remove(); });
  // ESC key
  const escHandler = e => {
    if (e.key === 'Escape') { modal.remove(); document.removeEventListener('keydown', escHandler); }
  };
  document.addEventListener('keydown', escHandler);
  document.body.appendChild(modal);

  // Add spinner animation
  if (!document.getElementById('blend-player-styles')) {
    const style = document.createElement('style');
    style.id = 'blend-player-styles';
    style.textContent = `
      @keyframes blendSpin { to { transform:rotate(360deg); } }
      @keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
      #blend-player-modal::-webkit-scrollbar { width:6px; }
      #blend-player-modal::-webkit-scrollbar-thumb { background:#2a2a2a; border-radius:3px; }
    `;
    document.head.appendChild(style);
  }

  // Fetch stream from backend
  blendFetchStream(url, ytId);
}

async function blendFetchStream(url, ytId) {
  const API_BASE = window.API_BASE || '';
  const statusEl = document.getElementById('bp-status');
  const spinnerEl = document.getElementById('bp-spinner');

  try {
    if (statusEl) statusEl.textContent = 'Extracting video stream via yt-dlp…';

    const apiUrl = `${API_BASE}/api/stream?url=${encodeURIComponent(url)}`;
    const res = await fetch(apiUrl, { signal: AbortSignal.timeout(45000) });
    const data = await res.json();

    if (!data.success) {
      throw new Error(data.error || 'Stream extraction failed');
    }

    // Update metadata
    const titleEl = document.getElementById('bp-title');
    const channelEl = document.getElementById('bp-channel');
    const viewsEl = document.getElementById('bp-views');
    const dateEl = document.getElementById('bp-date');
    const durEl = document.getElementById('bp-duration-meta');
    const ytLink = document.getElementById('bp-yt-link');

    if (titleEl && data.title) titleEl.textContent = data.title;
    if (channelEl) channelEl.textContent = data.channel || '';
    if (viewsEl) viewsEl.textContent = data.views ? `👁 ${data.views} views` : '';
    if (dateEl) dateEl.textContent = data.upload_date ? `📅 ${data.upload_date}` : '';
    if (durEl) durEl.textContent = data.duration ? `⏱ ${data.duration}` : '';
    if (ytLink && url) { ytLink.href = url; }

    const video = document.getElementById('bp-video');
    if (video) {
       const thumb = data.thumbnail || 'https://images.unsplash.com/photo-1614113489855-66422ad300a4?q=80&w=800&auto=format&fit=crop';
       video.poster = thumb;
       // Add a fallback background image style just in case poster fails
       video.style.backgroundImage = `url('${thumb}')`;
       video.style.backgroundSize = 'contain';
       video.style.backgroundPosition = 'center';
       video.style.backgroundRepeat = 'no-repeat';
    }

    // Auto-switch download to audio if audio-only
    if (data.is_audio_only) {
        const dlFormat = document.getElementById('bp-dl-format');
        const dlQuality = document.getElementById('bp-dl-quality');
        if (dlFormat && dlQuality) {
            dlFormat.value = 'audio';
            dlQuality.disabled = true;
            dlQuality.style.opacity = 0.5;
        }
    }

    // Load quality buttons
    const qualityBtns = document.getElementById('bp-quality-btns');
    const dlBtns = document.getElementById('bp-dl-btns');
    const streams = data.streams || [];

    if (qualityBtns && streams.length) {
      qualityBtns.innerHTML = streams.map((s, i) => {
        const bg = i === 0 ? 'rgba(0,201,167,0.15)' : 'transparent';
        const color = i === 0 ? '#00c9a7' : '#e0e0e0';
        return `<button onclick="blendSwitchStream('${escapeJs(s.url)}','${s.ext}'); document.getElementById('bp-quality-menu').style.display='none';"
                style="background:${bg};border:none;color:${color};padding:8px 12px;border-radius:4px;cursor:pointer;font-size:13px;font-weight:600;text-align:left;transition:all 0.2s;width:100%;"
                onmouseover="this.style.background='rgba(255,255,255,0.1)'"
                onmouseout="this.style.background='${bg}'">
          ${s.label} <span style="color:#777;font-size:10px;font-weight:500;">${s.ext.toUpperCase()}</span>
        </button>`;
      }).join('');
    }

    if (dlBtns) {
      // Buttons removed since we use Select dropdowns now.
    }

    // Load the best stream into HTML5 video
    const bestUrl = streams[0]?.url || data.best_stream;
    if (bestUrl) {
      blendSwitchStream(bestUrl, streams[0]?.ext || 'mp4');
    } else {
      throw new Error('No playable stream found');
    }

  } catch (err) {
    console.error('Blend stream error:', err);
    const loading = document.getElementById('bp-loading');
    const errorEl = document.getElementById('bp-error');
    const errorMsg = document.getElementById('bp-error-msg');
    
    // Instead of iframes, try Piped API direct fetching
    if (ytId) {
      if (statusEl) statusEl.textContent = 'Trying API proxy fallback...';
      const fallbackUrl = await fallbackPipedApi(ytId, 'video');
      if (fallbackUrl) {
        if (errorEl) errorEl.style.display = 'none';
        blendSwitchStream(fallbackUrl, 'mp4');
        return;
      }
      
      if (loading) loading.style.display = 'none';
      if (errorEl) {
          errorEl.style.display = 'block';
          errorEl.style.padding = '10px';
          errorEl.style.marginTop = '10px';
      }
      if (errorMsg) errorMsg.innerHTML = `<span>Direct stream blocked by YouTube.</span> <a href="https://youtube.com/watch?v=${ytId}" target="_blank" style="margin-left:10px;padding:6px 12px;background:#ff0000;color:white;border-radius:4px;text-decoration:none;font-weight:bold;display:inline-block;">▶ Play on YouTube</a>`;
    } else {
      const errFallback = document.getElementById('bp-yt-fallback');
      if (loading) loading.style.display = 'none';
      if (errorEl) errorEl.style.display = 'block';
      if (errorMsg) errorMsg.textContent = `Could not extract stream: ${err.message}`;
      if (errFallback && url) errFallback.href = url;
    }
  }
}

function blendSwitchStream(streamUrl, ext) {
  const video = document.getElementById('bp-video');
  const loading = document.getElementById('bp-loading');
  if (!video) return;

  const mimeMap = { mp4: 'video/mp4', webm: 'video/webm', m4a: 'audio/mp4' };
  const mime = mimeMap[ext] || 'video/mp4';

  // Show video, hide loading
  if (loading) loading.style.display = 'none';
  video.style.display = 'block';

  // Set source and play
  const currentTime = video.currentTime || 0;
  video.src = streamUrl;
  video.load();
  video.currentTime = currentTime;
  video.play().catch(e => console.log('Autoplay blocked:', e));
}

async function blendPlayerLoad() {
  const input = document.getElementById('bp-url-input');
  if (!input) return;
  const raw = input.value.trim();
  if (!raw) return;

  const ytId = extractYtId(raw);
  const url = ytId ? `https://www.youtube.com/watch?v=${ytId}` : raw;
  const title = document.getElementById('bp-title')?.textContent || 'Video';

  // Reset player state
  const loading = document.getElementById('bp-loading');
  const video = document.getElementById('bp-video');
  const errorEl = document.getElementById('bp-error');
  const statusEl = document.getElementById('bp-status');
  if (loading) loading.style.display = 'flex';
  if (video) { video.pause(); video.style.display = 'none'; video.src = ''; }
  if (errorEl) errorEl.style.display = 'none';
  if (statusEl) statusEl.textContent = 'Extracting stream…';

  window.BLEND_PLAYER = { url, ytId, title };
  if (ytId) {
    const ytLink = document.getElementById('bp-yt-link');
    if (ytLink) ytLink.href = `https://youtube.com/watch?v=${ytId}`;
  }

  await blendFetchStream(url, ytId);
}

function blendDownload(quality) {
  const url = window.BLEND_PLAYER?.url;
  if (url) downloadMusic(url, quality);
}



/* ── MUSIC PLAYER SYSTEM — Option C: yt-dlp → piped.video → YouTube link ── */
window.MUSIC_INDEX = -1;

async function playMusicTrack(idx) {
  if (!window.MUSIC_QUEUE || !window.MUSIC_QUEUE[idx]) return;
  window.MUSIC_INDEX = idx;
  const track = window.MUSIC_QUEUE[idx];
  const ytId = track.id;
  const ytUrl = ytId ? `https://www.youtube.com/watch?v=${ytId}` : track.url;

  // Update player UI
  document.getElementById('mp-title').textContent = track.title || 'Playing...';
  document.getElementById('music-player').classList.add('show');

  // Ensure player container exists
  let container = document.getElementById('mp-player-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'mp-player-container';
    container.style.cssText = 'width:100%;margin-top:8px;border-radius:8px;overflow:hidden;background:#111;';
    const mp = document.getElementById('music-player');
    mp.insertBefore(container, mp.lastElementChild);
  }

  // Show loading state
  container.innerHTML = `<div style="padding:12px 16px;font-size:13px;color:#aaa;display:flex;align-items:center;gap:8px;">
    <span style="display:inline-block;width:14px;height:14px;border:2px solid #555;border-top-color:#fff;border-radius:50%;animation:spin 0.8s linear infinite;"></span>
    Loading stream...
  </div>`;

  // ── Step 1: Try yt-dlp /api/stream for real audio URL ──
  if (ytUrl) {
    try {
      const streamRes = await fetch(API(`/api/stream?url=${encodeURIComponent(ytUrl)}`),
        { signal: AbortSignal.timeout(12000) });
      if (streamRes.ok) {
        const streamData = await streamRes.json();
        // Find best audio-only stream
        const audioStreams = (streamData.streams || []).filter(s =>
          s.ext === 'm4a' || s.ext === 'mp3' || s.ext === 'webm' ||
          (s.mime && s.mime.startsWith('audio'))
        );
        const bestStream = audioStreams[0] || streamData.streams?.[0];
        const streamUrl = bestStream?.url || streamData.best_stream;

        if (streamUrl) {
          // ✅ HTML5 <audio> playback — no iframes, no Cloudflare
          container.innerHTML = `
            <audio id="mp-audio" controls autoplay style="width:100%;border-radius:8px;background:#1a1a1a;">
              <source src="${streamUrl}" type="${bestStream?.mime || 'audio/mp4'}">
              Your browser does not support audio playback.
            </audio>
            <div style="padding:8px 12px;display:flex;gap:10px;align-items:center;">
              ${ ytUrl ? `<a href="${ytUrl}" target="_blank" style="font-size:12px;color:#4da6ff;text-decoration:none;">▶ Open on YouTube</a>` : '' }
              ${ ytUrl ? `<button onclick="downloadMusic('${ytUrl}','bestaudio')" style="font-size:12px;padding:4px 10px;border:1px solid #444;border-radius:6px;background:none;color:#ccc;cursor:pointer;">⬇ Download</button>` : '' }
            </div>`;
          document.getElementById('mp-audio')?.play().catch(() => {});
          return; // ✅ Done
        }
      }
    } catch (e) {
      console.warn('yt-dlp stream failed, trying piped.video:', e);
    }
  }

  // ── Step 2: Fallback — Piped API Fetch (No Iframes) ──
  if (ytId) {
    container.innerHTML = `<div style="padding:12px 16px;font-size:13px;color:#aaa;display:flex;align-items:center;gap:8px;">
      <span style="display:inline-block;width:14px;height:14px;border:2px solid #555;border-top-color:#fff;border-radius:50%;animation:spin 0.8s linear infinite;"></span>
      Trying API proxy fallback...
    </div>`;
    const fallbackUrl = await fallbackPipedApi(ytId, 'audio');
    if (fallbackUrl) {
      container.innerHTML = `
        <audio id="mp-audio" controls autoplay style="width:100%;border-radius:8px;background:#1a1a1a;">
          <source src="${fallbackUrl}" type="audio/mp4">
          Your browser does not support audio playback.
        </audio>
        <div style="padding:8px 12px;display:flex;gap:10px;align-items:center;">
          ${ ytUrl ? `<a href="${ytUrl}" target="_blank" style="font-size:12px;color:#4da6ff;text-decoration:none;">▶ Open on YouTube</a>` : '' }
          ${ ytUrl ? `<button onclick="downloadMusic('${ytUrl}','bestaudio')" style="font-size:12px;padding:4px 10px;border:1px solid #444;border-radius:6px;background:none;color:#ccc;cursor:pointer;">⬇ Download</button>` : '' }
          <span style="font-size:11px;color:#888;margin-left:auto;">via Proxy API</span>
        </div>`;
      document.getElementById('mp-audio')?.play().catch(() => {});
      return;
    }
  }

  // ── Step 3: Last resort — just show YouTube link ──
  container.innerHTML = `
    <div style="padding:16px;text-align:center;">
      <p style="color:#aaa;font-size:14px;margin:0 0 10px;">Direct stream blocked by YouTube.</p>
      ${ ytUrl ? `<a href="${ytUrl}" target="_blank" style="padding:8px 20px;background:#ff0000;color:#fff;border-radius:8px;text-decoration:none;font-size:14px;display:inline-block;font-weight:bold;">▶ Play on YouTube</a>` : '<p style="color:#666;">No playback source available.</p>' }
    </div>`;
}

function nextMusic() {
  if (window.MUSIC_INDEX < window.MUSIC_QUEUE.length - 1) {
    playMusicTrack(window.MUSIC_INDEX + 1);
  }
}

function prevMusic() {
  if (window.MUSIC_INDEX > 0) {
    playMusicTrack(window.MUSIC_INDEX - 1);
  }
}

function closeMusicPlayer() {
  document.getElementById('music-player').classList.remove('show');
  const container = document.getElementById('mp-player-container');
  if (container) {
    // Stop audio playback
    const audio = container.querySelector('audio');
    if (audio) { audio.pause(); audio.src = ''; }
    container.innerHTML = '';
  }
}

/* ── SEARCH ── */
const blendChannel = 'BroadcastChannel' in window ? new BroadcastChannel('blend_search') : null;
if (blendChannel) {
  blendChannel.onmessage = (e) => {
    if (e.data && e.data.type === 'new_search') {
      const input = document.getElementById('top-search');
      if (input) input.value = e.data.query || '';
    }
  };
}

function submitSearch() {
  const q = document.getElementById('top-search').value.trim();
  if (q) {
    if (!q.includes(' ') && /^(https?:\/\/)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(:\d+)?(\/.*)?$/.test(q)) {
      window.location.href = q.startsWith('http') ? q : 'https://' + q;
      return;
    }
    const tab = new URLSearchParams(window.location.search).get('tab') || 'web';
    const mode = document.getElementById('mode-select')?.value || 'fast';
    const modePart = mode === 'deep' ? '&mode=deep' : '';
    if (blendChannel) blendChannel.postMessage({ type: 'new_search', query: q });
    sessionStorage.setItem('blend_q', q);
    window.location.href = `results.html?q=${encodeURIComponent(q)}&tab=${tab}${modePart}`;
  }
}
function clearSearch() {
  document.getElementById('top-search').value = '';
  document.getElementById('top-search').focus();
}
document.getElementById('top-search').addEventListener('keydown', e => { if(e.key==='Enter') submitSearch(); });

/* ── MISC ── */
function togglePill(el) { el.classList.toggle('active'); }
document.addEventListener('keydown', e => { if(e.key==='Escape') { closeLightbox(); closeVideoModal(); } });

/* ── INIT ── */
(function init() {
  const params = new URLSearchParams(window.location.search);
  let q = params.get('q');
  
  // Privacy Feature: Scrub query from URL so it doesn't appear in browser history
  if (q) {
    sessionStorage.setItem('blend_q', q);
    if (window.history.replaceState) {
      const scrubbedUrl = new URL(window.location);
      scrubbedUrl.searchParams.delete('q');
      window.history.replaceState(null, '', scrubbedUrl.toString());
    }
  } else {
    q = sessionStorage.getItem('blend_q') || 'open source software India';
  }

  const tab = params.get('tab') || 'web';
  const lang = params.get('language') || 'all';
  const mode = params.get('mode') === 'deep' ? 'deep' : 'fast';
  
  document.getElementById('top-search').value = q;
  document.getElementById('lang-select').value = lang;
  document.getElementById('mode-select').value = mode;
  
  window.LANG_PARAM = lang !== 'all' ? `&language=${lang}` : '';
  
  document.title = `${q} — Blend Search`;
  window.CURRENT_RESULTS = [];
  window.SECTION_CACHE = window.SECTION_CACHE || {};
  
  renderWeb(q);
  if (tab === 'images') renderImages(q);
  if (tab === 'videos') renderVideos(q);
  if (tab === 'news') renderNews(q);
  if (tab === 'maps') renderMapPlaces(q);
  if (tab === 'music') renderMusic(q);
  if (tab === 'files') renderFiles(q);
  if (tab === 'social') renderSocial(q);
  switchTab(tab);

  // Wake up Render Backend
  fetch(API('/ping')).catch(() => console.log('Pinged backend'));
})();

/* ── AI CHAT LOGIC ── */
async function sendAiMessage() {
  const input = document.getElementById('ai-chat-input');
  const text = input.value.trim();
  if (!text) return;
  
  const messagesBox = document.getElementById('ai-chat-messages');
  
  // User message
  const userMsg = document.createElement('div');
  userMsg.style.cssText = 'align-self:flex-end;background:var(--accent);color:#000;padding:12px 16px;border-radius:12px;max-width:80%;font-size:14px;line-height:1.5;';
  userMsg.textContent = text;
  messagesBox.appendChild(userMsg);
  
  input.value = '';
  messagesBox.scrollTop = messagesBox.scrollHeight;

  // Navar Loading
  const aiMsg = document.createElement('div');
  aiMsg.className = 'ai-msg-container';
  aiMsg.style.cssText = 'position:relative; align-self:flex-start;background:var(--surface-hover);padding:12px 16px;border-radius:12px;max-width:80%;font-size:14px;line-height:1.5;';
  aiMsg.innerHTML = 'Thinking...';
  messagesBox.appendChild(aiMsg);
  messagesBox.scrollTop = messagesBox.scrollHeight;

  try {
    const mode = document.getElementById('mode-select').value;
    const shortcuts = localStorage.getItem('blend_shortcuts') || '[]';
    const bodyData = { 
      query: text, 
      mode: mode, 
      results: window.CURRENT_RESULTS, 
      section_cache: window.SECTION_CACHE || {},
      shortcuts: JSON.parse(shortcuts),
      current_tab: new URLSearchParams(window.location.search).get('tab') || 'web',
      current_url: window.location.href
    };
    
    // Create a container for the status and text
    aiMsg.innerHTML = '<div class="ai-status-bar" style="font-size:12px; color:#06d6a0; margin-bottom:12px; font-weight:600; font-family: monospace;">[ ] Initializing orchestrator...</div><div class="ai-text-content" style="position:relative;width:100%;word-wrap:break-word;user-select:text;"></div>';
    const statusDiv = aiMsg.querySelector('.ai-status-bar');
    const textDiv = aiMsg.querySelector('.ai-text-content');
    
    const res = await fetch(API('/api/ai'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bodyData)
    });
    
    const reader = res.body.getReader();
    const decoder = new TextDecoder('utf-8');
    let buffer = '';
    
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n\n');
      buffer = lines.pop(); 
      
      for (const line of lines) {
        if (line.startsWith('data: ')) {
           try {
             const data = JSON.parse(line.substring(6));
             if (data.type === 'status') {
               statusDiv.textContent = data.message;
             } else if (data.type === 'text') {
               textDiv.rawText = (textDiv.rawText || '') + data.chunk;
               textDiv.innerHTML = formatAiText(textDiv.rawText);
               messagesBox.scrollTop = messagesBox.scrollHeight;
             } else if (data.type === 'action') {
               if (data.action === 'render_map') {
                  const mapId = 'map-' + Math.random().toString(36).substring(7);
                  textDiv.innerHTML += `<div style="margin:16px 0; border-radius:12px; overflow:hidden; border:1px solid var(--border2);"><div id="${mapId}" style="height:250px; width:100%; background:#e0e0e0; z-index:0;"></div></div>`;
                  if (typeof L !== 'undefined') {
                    setTimeout(() => {
                      const map = L.map(mapId).setView(data.coords, 13);
                      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
                      L.marker(data.coords).addTo(map).bindPopup(data.place).openPopup();
                    }, 100);
                  }
               }
             } else if (data.type === 'suggested_filters') {
               statusDiv.innerHTML = `<span style="color:var(--text3);font-weight:normal;">Orchestration complete. Suggestions: ${data.filters.join(', ')}</span>`;
               const tabs = document.querySelectorAll('.tab-btn');
               tabs.forEach(t => {
                 if(data.filters.map(f=>f.toLowerCase()).includes(t.dataset.tab.toLowerCase())) {
                   t.style.animation = 'pulse 1.5s infinite';
                   setTimeout(() => t.style.animation = '', 6000);
                 }
               });
             }
           } catch (e) { console.error('SSE JSON error', e); }
        }
      }
    }
    
    // Add pulsing CSS if not present
    if (!document.getElementById('pulse-css')) {
      const style = document.createElement('style');
      style.id = 'pulse-css';
      style.innerHTML = `@keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(224,90,43, 0.4); } 70% { box-shadow: 0 0 0 6px rgba(224,90,43, 0); } 100% { box-shadow: 0 0 0 0 rgba(224,90,43, 0); } }`;
      document.head.appendChild(style);
    }
  } catch (err) {
    aiMsg.textContent = "Error connecting to Navar AI backend.";
  }
  smoothScrollBottom();
}

function formatAiText(text, sources=[]) {
  let formatted = String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, '<a href="$2" target="${LINK_TARGET}" style="color:var(--link);text-decoration:underline;">$1</a>')
    .replace(/\n/g, '<br/>');

  // Replace strictly numbered citations like [1], [2] with interactive badges
  if (sources && sources.length > 0) {
      formatted = formatted.replace(/\[(\d+)\]/g, (match, p1) => {
          const index = parseInt(p1, 10);
          if (index > 0 && index <= sources.length) {
              const url = sources[index - 1].url;
              return `<a href="${url}" target="_blank" class="ai-inline-citation">${index}</a>`;
          }
          return match; // If index is out of bounds, leave it alone
      });
  }
  return formatted;
}

function smoothScrollBottom() {
  const box = document.getElementById('ai-chat-messages');
  if (!box) return;
  box.scrollTo({ top: box.scrollHeight, behavior: 'smooth' });
}

function handleModeChange() {
  const mode = document.getElementById('mode-select').value;
  const q = document.getElementById('top-search')?.value?.trim() || sessionStorage.getItem('blend_q') || '';
  const url = new URL(window.location);
  if (mode === 'deep') {
    const tab = currentTabName() === 'ai' ? 'web' : currentTabName();
    url.searchParams.set('mode', 'deep');
    url.searchParams.set('tab', tab);
    history.replaceState({}, '', url);
    resetSearchModeState();
    showDeepSearchPending(tab, q);
    switchTab(tab);
    if (['maps', 'music'].includes(tab) && q) renderActiveSearchTab(tab, q);
    const input = document.getElementById('ai-chat-input');
    if (input) input.placeholder = "Ask Navar anything...";
    return;
  }

  url.searchParams.delete('mode');
  history.replaceState({}, '', url);

  if (mode === 'dork') {
    const panel = document.getElementById('deep-search-panel');
    if (panel) panel.style.display = 'none';
    switchTab('ai');
    const input = document.getElementById('ai-chat-input');
    input.placeholder = "Enter target for AI Google Dorks...";
    input.focus();
  } else {
    const input = document.getElementById('ai-chat-input');
    if (input) input.placeholder = "Ask Navar anything...";
    const tab = currentTabName() === 'ai' ? 'web' : currentTabName();
    resetSearchModeState();
    switchTab(tab);
    if (['maps', 'music'].includes(tab) && q) renderActiveSearchTab(tab, q);
  }
}

/* ── MESSAGE CONTEXT MENU ── */
let activeContextMenu = null;

function showMessageMenu(event, msgId, content) {
  // Remove existing menu
  if (activeContextMenu) activeContextMenu.remove();
  
  const menu = document.createElement('div');
  menu.style.cssText = `
    position: fixed;
    top: ${event.clientY}px;
    left: ${event.clientX}px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 8px;
    box-shadow: 0 4px 16px rgba(0,0,0,0.3);
    z-index: 10000;
    min-width: 140px;
    overflow: hidden;
  `;
  
  menu.innerHTML = `
    <button style="
      display: block;
      width: 100%;
      padding: 10px 14px;
      background: none;
      border: none;
      text-align: left;
      color: var(--text);
      cursor: pointer;
      font-size: 13px;
      transition: background 0.15s;
      border-bottom: 1px solid var(--border);
    " onmouseover="this.style.background='var(--surface-hover)'" onmouseout="this.style.background='none'" onclick="
      navigator.clipboard.writeText('${content.replace(/'/g, "\\'")}');
      alert('Copied to clipboard!');
      this.parentElement.remove();
    ">📋 Copy</button>
    <button style="
      display: block;
      width: 100%;
      padding: 10px 14px;
      background: none;
      border: none;
      text-align: left;
      color: var(--link);
      cursor: pointer;
      font-size: 13px;
      transition: background 0.15s;
    " onmouseover="this.style.background='var(--surface-hover)'" onmouseout="this.style.background='none'" onclick="
      document.getElementById('${msgId}').closest('.ai-msg-container').remove();
      this.parentElement.remove();
    ">🗑️ Delete</button>
  `;
  
  document.body.appendChild(menu);
  activeContextMenu = menu;
  
  // Close on click outside
  setTimeout(() => {
    document.addEventListener('click', function closeMenu(e) {
      if (e.target !== menu && !menu.contains(e.target)) {
        menu.remove();
        activeContextMenu = null;
        document.removeEventListener('click', closeMenu);
      }
    });
  }, 100);
}
